package DAOLayer;
import EntityLayer.*;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.swing.JOptionPane;

public class MemberDAO {

	private Connection myCon;
	
	public MemberDAO()
	{
		try {
			myCon=DriverManager.getConnection("jdbc:mysql://localhost:3306/meal management", "root", "");
		} 
		catch (Exception e) {
			JOptionPane.showMessageDialog(null, "Connection unsuccesful");
		}
	}
	
	public ArrayList<Member> GetAllMember()
	{
		ArrayList<Member> member = new ArrayList<Member>();
		
		Statement myStatement = null;
		ResultSet myResultSet = null;
		
		try
		{
			if(myCon==null)
			{
				throw(new Exception("connection unsuccesful"));
			}
			myStatement = myCon.createStatement();
			myResultSet = myStatement.executeQuery("select * from Member");
			
			while(myResultSet.next())
			{
				Member m = convertRowToMember(myResultSet);
				member.add(m);
			}
		}
		catch(Exception e)
		{
			JOptionPane.showMessageDialog(null, e.getMessage());
		}
		finally
		{
			close(myStatement,null,myResultSet);
		}
		
		return member;
	}

	
	private Member convertRowToMember(ResultSet myResultSet) throws SQLException 
	{
		Member m = new Member();
		m.setID(myResultSet.getInt("ID"));
		m.setName(myResultSet.getString("Name"));
		m.setYOB(myResultSet.getString("YOB"));
		m.setOccupation(myResultSet.getString("Occupation"));
		m.setHomeTown(myResultSet.getString("Home Town"));
		m.setPhoneNo(myResultSet.getString("Phone No"));
		
		return m;
	}

	private void close(Statement myStatement,PreparedStatement preparedStatement , ResultSet myResultSet) {
	try
	{
		if(myStatement!=null)
			myStatement.close();
		if(preparedStatement!=null)
			preparedStatement.close();
		if(myResultSet!=null)
			myResultSet.close();
		
	}
	catch(Exception e)
	{
		JOptionPane.showMessageDialog(null, e.getMessage());
	}
	
	}

	public boolean DeleteMember(int id) {
		PreparedStatement prepareStatement = null;
		try
		{
			prepareStatement = myCon.prepareStatement("Delete from Member where ID=?");
			prepareStatement.setInt(1, id);
			int row = prepareStatement.executeUpdate();
			
			return row>0;
		}
		catch(Exception e)
		{
			JOptionPane.showMessageDialog(null,e.getMessage());
		}
		finally
		{
			close(null,prepareStatement,null);
		}
		return false;
	}
	
}
