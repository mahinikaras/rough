package DAOLayer;
import EntityLayer.*;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.swing.JOptionPane;

public class adminsDAO {

	private Connection myCon;
	
	public adminsDAO()
	{
		try {
			myCon=DriverManager.getConnection("jdbc:mysql://localhost:3306/meal management", "root", "");
		} 
		catch (Exception e) {
			JOptionPane.showMessageDialog(null, "Connection unsuccesful");
		}
	}
	
	public Admins Login(String UserName,String Password)
	{
		Admins a = new Admins();
		a.setAccessNo(-1);
		
		Statement myStatement=null;
		ResultSet myResultSet=null;
		try
		{
			myStatement = myCon.createStatement();
			myResultSet = myStatement.executeQuery("Select * from admins where UserName='"+UserName+"' and Password='"+Password+"'");
			if(myResultSet.next())
				a=convertRowToAdmins(myResultSet);
		}
		catch(Exception e)
		{
			JOptionPane.showMessageDialog(null, e.getMessage());
		}
		return a;
	}
	
	private Admins convertRowToAdmins(ResultSet myResultSet) throws SQLException 
	{
		Admins m = new Admins();
		m.setAccessNo(myResultSet.getInt("AccessNo"));
		m.setUserName(myResultSet.getString("UserName"));
		m.setPassword(myResultSet.getString("Password"));
		m.setName(myResultSet.getString("Name"));
		m.setBirthYear(myResultSet.getString("BirthYear"));
		m.setOccupation(myResultSet.getString("Occupation"));
		m.setHomeTown(myResultSet.getString("HomeTown"));
		m.setPhoneNo(myResultSet.getString("PhoneNo"));
		
		return m;
	}

	private void close(Statement myStatement,PreparedStatement preparedStatement , ResultSet myResultSet) {
	try
	{
		if(myStatement!=null)
			myStatement.close();
		if(preparedStatement!=null)
			preparedStatement.close();
		if(myResultSet!=null)
			myResultSet.close();
		
	}
	catch(Exception e)
	{
		JOptionPane.showMessageDialog(null, e.getMessage());
	}
	
	}

	
}
