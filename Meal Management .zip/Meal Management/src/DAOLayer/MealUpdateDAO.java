package DAOLayer;
import EntityLayer.*;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.swing.JOptionPane;

public class MealUpdateDAO {

	private Connection myCon;
	
	public MealUpdateDAO()
	{
		try {
			myCon=DriverManager.getConnection("jdbc:mysql://localhost:3306/meal management", "root", "");
		} 
		catch (Exception e) {
			JOptionPane.showMessageDialog(null, "Connection unsuccesful");
		}
	}
	
	public ArrayList<MealUpdate> GetAllMealUpdate()
	{
		ArrayList<MealUpdate> MealUpdate = new ArrayList<MealUpdate>();
		
		Statement myStatement = null;
		ResultSet myResultSet = null;
		
		try
		{
			if(myCon==null)
			{
				throw(new Exception("connection unsuccesful"));
			}
			myStatement = myCon.createStatement();
			myResultSet = myStatement.executeQuery("select * from MealUpdate");
			
			while(myResultSet.next())
			{
				MealUpdate m = convertRowToMealUpdate(myResultSet);
				MealUpdate.add(m);
			}
		}
		catch(Exception e)
		{
			JOptionPane.showMessageDialog(null, e.getMessage());
		}
		finally
		{
			close(myStatement,null,myResultSet);
		}
		
		return MealUpdate;
	}

	
	private MealUpdate convertRowToMealUpdate(ResultSet myResultSet) throws SQLException 
	{
		MealUpdate m = new MealUpdate();
		m.setDate(myResultSet.getInt("Date"));
		m.setDipon(myResultSet.getInt("Dipon"));
		m.setMahin(myResultSet.getInt("Mahin"));
		m.setRahat(myResultSet.getInt("Rahat"));
		m.setShurid(myResultSet.getInt("Shurid"));
		m.setSajid(myResultSet.getInt("Sajid"));
		m.setTanim(myResultSet.getInt("Tanim"));
		m.setTonmoy(myResultSet.getInt("Tonmoy"));
		return m;
	}

	private void close(Statement myStatement,PreparedStatement preparedStatement , ResultSet myResultSet) {
	try
	{
		if(myStatement!=null)
			myStatement.close();
		if(preparedStatement!=null)
			preparedStatement.close();
		if(myResultSet!=null)
			myResultSet.close();
		
	}
	catch(Exception e)
	{
		JOptionPane.showMessageDialog(null, e.getMessage());
	}
	
	}

	
}
