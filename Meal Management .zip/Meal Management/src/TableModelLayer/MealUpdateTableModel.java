package TableModelLayer;

import java.util.ArrayList;

import javax.swing.table.AbstractTableModel;

import EntityLayer.MealUpdate;

public class MealUpdateTableModel extends AbstractTableModel{

	private String[] colNames = {"Date","Dipon","Mahin","Rahat","Shurid","Sajid","Tanim","Tonmoy"};
	private ArrayList<MealUpdate> tblMealUpdate = new ArrayList<MealUpdate>();
	
	public MealUpdateTableModel(ArrayList<MealUpdate> m)
	{
		tblMealUpdate = m;
	}
	@Override
	public int getColumnCount() {
		return colNames.length;
	}

	@Override
	public int getRowCount() {
		return tblMealUpdate.size();
	}
	
	public String getColumnName(int col)
	{
		return colNames[col];
	}

	@Override
	public Object getValueAt(int row, int col) {
		
		MealUpdate m = tblMealUpdate.get(row);
		
		switch(col)
		{
		case 0:
			return m.getDate();
		case 1:
			return m.getDipon();
		case 2:
			return m.getMahin();
		case 3:
			return m.getRahat();
		case 4:
			return m.getShurid();
		case 5:
			return m.getSajid();
		case 6:
			return m.getTanim();
		case 7:
			return m.getTonmoy();
		default:
			return m.getDate();
			
		}
	}

}
