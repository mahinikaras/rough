package TableModelLayer;

import java.util.ArrayList;

import javax.swing.table.AbstractTableModel;

import EntityLayer.Member;

public class MemberTableModel extends AbstractTableModel{

	private String[] colNames = {"ID","Name","YOB","Home Town","Occupation","Phone No"};
	private ArrayList<Member> tblMember = new ArrayList<Member>();
	
	public MemberTableModel(ArrayList<Member> m)
	{
		tblMember = m;
	}
	@Override
	public int getColumnCount() {
		return colNames.length;
	}

	@Override
	public int getRowCount() {
		return tblMember.size();
	}
	
	public String getColumnName(int col)
	{
		return colNames[col];
	}

	@Override
	public Object getValueAt(int row, int col) {
		
		Member m = tblMember.get(row);
		
		switch(col)
		{
		case 0:
			return m.getID();
		case 1:
			return m.getName();
		case 2:
			return m.getYOB();
		case 3:
			return m.getHomeTown();
		case 4:
			return m.getOccupation();
		case 5:
			return m.getPhoneNo();
		default:
			return m.getID();
		}
	}

}
