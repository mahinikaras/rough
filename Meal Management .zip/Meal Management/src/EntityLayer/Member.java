package EntityLayer;

public class Member {
	
	private int ID;
	private String Name;
	private String YOB;
	private String HomeTown;
	private String Occupation;
	private String PhoneNo;
	public int getID() {
		return ID;
	}
	public void setID(int iD) {
		ID = iD;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getHomeTown() {
		return HomeTown;
	}
	public void setHomeTown(String homeTown) {
		HomeTown = homeTown;
	}
	public String getYOB() {
		return YOB;
	}
	public void setYOB(String yOB) {
		YOB = yOB;
	}
	public String getPhoneNo() {
		return PhoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		PhoneNo = phoneNo;
	}
	public String getOccupation() {
		return Occupation;
	}
	public void setOccupation(String occupation) {
		Occupation = occupation;
	}

}
