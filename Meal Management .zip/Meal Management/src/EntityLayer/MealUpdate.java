package EntityLayer;

public class MealUpdate {
	
	private int Date;
	private int Dipon;
	private int Mahin;
	private int Rahat;
	private int Shurid;
	private int Sajid;
	private int Tanim;
	private int Tonmoy;
	public int getDate() {
		return Date;
	}
	public void setDate(int date) {
		Date = date;
	}
	public int getMahin() {
		return Mahin;
	}
	public void setMahin(int mahin) {
		Mahin = mahin;
	}
	public int getShurid() {
		return Shurid;
	}
	public void setShurid(int shurid) {
		Shurid = shurid;
	}
	public int getRahat() {
		return Rahat;
	}
	public void setRahat(int rahat) {
		Rahat = rahat;
	}
	public int getDipon() {
		return Dipon;
	}
	public void setDipon(int dipon) {
		Dipon = dipon;
	}
	public int getTanim() {
		return Tanim;
	}
	public void setTanim(int tanim) {
		Tanim = tanim;
	}
	public int getSajid() {
		return Sajid;
	}
	public void setSajid(int sajid) {
		Sajid = sajid;
	}
	public int getTonmoy() {
		return Tonmoy;
	}
	public void setTonmoy(int tonmoy) {
		Tonmoy = tonmoy;
	}

}
