package EntityLayer;

public class Admins {
	
	private int AccessNo;
	private String UserName;
	private String Password;
	private String Name;
	private String BirthYear;
	private String HomeTown;
	private String Occupation;
	private String PhoneNo;
	
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getHomeTown() {
		return HomeTown;
	}
	public void setHomeTown(String homeTown) {
		HomeTown = homeTown;
	}
	
	public String getPhoneNo() {
		return PhoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		PhoneNo = phoneNo;
	}
	public String getOccupation() {
		return Occupation;
	}
	public void setOccupation(String occupation) {
		Occupation = occupation;
	}
	public String getBirthYear() {
		return BirthYear;
	}
	public void setBirthYear(String birthYear) {
		BirthYear = birthYear;
	}
	public String getUserName() {
		return UserName;
	}
	public void setUserName(String userName) {
		UserName = userName;
	}
	public int getAccessNo() {
		return AccessNo;
	}
	public void setAccessNo(int accessNo) {
		AccessNo = accessNo;
	}
	public String getPassword() {
		return Password;
	}
	public void setPassword(String password) {
		Password = password;
	}

}
