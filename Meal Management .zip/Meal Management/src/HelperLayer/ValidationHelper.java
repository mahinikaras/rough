package HelperLayer;

public class ValidationHelper {

	public static boolean isIntValid(String Data)
	{
		try
		{
			Integer.parseInt(Data);
			return true;
		}
		catch(Exception e)
		{
			return false;
		}
	}
	
	public static boolean isFloatValid(String Data)
	{
		try
		{
			Float.parseFloat(Data);
			return true;
		}
		catch(Exception e)
		{
			return false;
		}
	}
}
