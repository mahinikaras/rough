package HelperLayer;

import EntityLayer.Admins;

public class LoginHelper {

	public static Admins loginuser=null;
}
