package GUILayer;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import DAOLayer.MemberDAO;
import EntityLayer.Member;
import HelperLayer.ValidationHelper;

public class AddMember extends JFrame{

private Connection myCon;
	
	
	
	JButton Add;
	JLabel UserName,Password,Name,BirthYear,HomeTown,Occupation,CheckPassword,PhoneNo,ID;
	JPasswordField txtPassword,txtCheckPassword;
	JTextField txtUserName,txtName,txtBirthYear,txtHomeTown,txtOccupation,txtPhoneNo,txtID;
	
	public AddMember()
	{
		try {
			myCon=DriverManager.getConnection("jdbc:mysql://localhost:3306/meal management", "root", "");
		} 
		catch (Exception e) {
			JOptionPane.showMessageDialog(null, "Connection unsuccesful");
		}
		this.setTitle("Meal Management");
		   this.setSize(500,500);
		   this.setLocationRelativeTo(null);
		   this.setLayout(null);
		  // this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		   this.addAddMemberPageComponent();
		   //this.addKeyListener(new keyHandler());
		   //this.setFocusable(true);
	}
	

	private void addAddMemberPageComponent() {
		

		
		ID = new JLabel("ID                    :");
		ID.setBounds(133, 50, 79,20);
		this.add(ID);
		
		txtID= new JTextField();
		txtID.setBounds(220, 50, 150, 20);
		this.add(txtID);
		
		Name = new JLabel("Name             :");
		Name.setBounds(130, 80, 79,20);
		this.add(Name);
		
		txtName = new JTextField();
		txtName.setBounds(220, 80, 150,20);
		this.add(txtName);
		
		BirthYear = new JLabel("Birth Year     :");
		BirthYear.setBounds(130, 110, 79,20);
		this.add(BirthYear);
		
		txtBirthYear = new JTextField();
		txtBirthYear.setBounds(220, 110, 150, 20);
		this.add(txtBirthYear);
		
		HomeTown = new JLabel("Home Town :");
		HomeTown.setBounds(130, 140, 79,20);
		this.add(HomeTown);
		
		txtHomeTown = new JTextField();
		txtHomeTown.setBounds(220, 140, 150, 20);
		this.add(txtHomeTown);
		
		Occupation = new JLabel("Occupation :");
		Occupation.setBounds(130, 170, 75,20);
		this.add(Occupation);
		
		txtOccupation = new JTextField();
		txtOccupation.setBounds(220, 170, 150,20);
		this.add(txtOccupation);
		
		PhoneNo = new JLabel("Phone No.    :");
		PhoneNo.setBounds(130, 200, 75,20);
		this.add(PhoneNo);
		
		txtPhoneNo = new JTextField();
		txtPhoneNo.setBounds(220, 200, 150,20);
		this.add(txtPhoneNo);
		
		
		
		Add = new JButton("Add");
		Add.setBounds(220, 230, 100,20);
		Add.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				if(!isValidData())
					{
					return;
					}
				
				if(InsertMember())
				{
					JOptionPane.showMessageDialog(null, "member added successfully");
					closeframe();
				}
				//closeframe();
			}

		});
		this.add(Add);
	}
	
	private void closeframe()
	{
		super.dispose();
	}
	public  boolean InsertMember()
	{
		PreparedStatement myPreparedStatement = null;
		
		try
		{
			myPreparedStatement = myCon.prepareStatement("Insert into Member values(?,?,?,?,?,?)");
			
			myPreparedStatement.setInt(1,Integer.parseInt(txtID.getText()));
			myPreparedStatement.setString(2,txtName.getText() );
			myPreparedStatement.setString(3,txtBirthYear.getText() );
			myPreparedStatement.setString(4,txtHomeTown.getText() );
			myPreparedStatement.setString(5, txtOccupation.getText());
			myPreparedStatement.setString(6, txtPhoneNo.getText());
			
			int i = myPreparedStatement.executeUpdate();
			
			return i>0;
		}
		catch(Exception e)
		{
			JOptionPane.showMessageDialog(null, e.getMessage());
		}
		finally
		{
			close(null,myPreparedStatement,null);
		}
		return false;
	}
	private void close(Statement myStatement,PreparedStatement preparedStatement , ResultSet myResultSet) {
	try
	{
		if(myStatement!=null)
			myStatement.close();
		if(preparedStatement!=null)
			preparedStatement.close();
		if(myResultSet!=null)
			myResultSet.close();
		
	}
	catch(Exception e)
	{
		JOptionPane.showMessageDialog(null, e.getMessage());
	}
	
	}
	
	
	private boolean isValidData()
	{
		if(!ValidationHelper.isIntValid(txtID.getText()))
		{
			JOptionPane.showMessageDialog(null, "Invalid id");
			return false;
		}
		if(txtName.getText().isEmpty())
		{
			JOptionPane.showMessageDialog(null, "Invalid Name");
			return false;
		}
		if(txtBirthYear.getText().isEmpty())
		{
			JOptionPane.showMessageDialog(null, "Invalid Birth Year");
			return false;
		}
		if(txtHomeTown.getText().isEmpty())
		{
			JOptionPane.showMessageDialog(null, "Invalid Home Town");
			return false;
		}
		if(txtOccupation.getText().isEmpty())
		{
			JOptionPane.showMessageDialog(null, "Invalid Occupation");
			return false;
		}
		if(txtPhoneNo.getText().isEmpty())
		{
			JOptionPane.showMessageDialog(null, "Invalid Phone No");
			return false;
		}
		return true;
	}
}


