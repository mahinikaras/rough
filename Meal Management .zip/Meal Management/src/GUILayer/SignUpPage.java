package GUILayer;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import HelperLayer.ValidationHelper;

public class SignUpPage extends JFrame {
	
	private Connection myCon;
	
	JButton SignUp;
	JLabel UserName,Password,Name,BirthYear,HomeTown,Occupation,CheckPassword,PhoneNo,AccessNo;
	JPasswordField txtPassword,txtCheckPassword,txtAccessNo;
	JTextField txtUserName,txtName,txtBirthYear,txtHomeTown,txtOccupation,txtPhoneNo;
	
	public SignUpPage()
	{
		try {
			myCon=DriverManager.getConnection("jdbc:mysql://localhost:3306/meal management", "root", "");
		} 
		catch (Exception e) {
			JOptionPane.showMessageDialog(null, "Connection unsuccesful");
		}
		   this.setTitle("Meal Management");
		   this.setSize(500,500);
		   this.setLocationRelativeTo(null);
		   this.setLayout(null);
		   //this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		   this.addLoginPageComponent();
		   //this.addKeyListener(new keyHandler());
		   //this.setFocusable(true);
	}

	private void addLoginPageComponent() {
		
		
		AccessNo = new JLabel("Access No     :");
		AccessNo.setBounds(130, 50, 79,20);
		this.add(AccessNo);
		
		txtAccessNo = new JPasswordField();
		txtAccessNo.setBounds(220, 50, 150,20);
		this.add(txtAccessNo);
		
		UserName = new JLabel("User Name    :");
		UserName.setBounds(130, 80, 79,20);
		this.add(UserName);
		
		txtUserName = new JTextField();
		txtUserName.setBounds(220, 80, 150,20);
		this.add(txtUserName);
		
		Password = new JLabel("Password     :");
		Password.setBounds(130, 110, 79,20);
		this.add(Password);
		
		txtPassword = new JPasswordField();
		txtPassword.setBounds(220, 110, 150, 20);
		this.add(txtPassword);
		
		CheckPassword = new JLabel("PW Check    :");
		CheckPassword.setBounds(130, 140, 79,20);
		this.add(CheckPassword);
		
		txtCheckPassword= new JPasswordField();
		txtCheckPassword.setBounds(220, 140, 150, 20);
		this.add(txtCheckPassword);
		
		Name = new JLabel("Name             :");
		Name.setBounds(130, 170, 75,20);
		this.add(Name);
		
		txtName = new JTextField();
		txtName.setBounds(220, 170, 150,20);
		this.add(txtName);
		
		BirthYear = new JLabel("Birth Year     :");
		BirthYear.setBounds(130, 200, 75,20);
		this.add(BirthYear);
		
		txtBirthYear = new JTextField();
		txtBirthYear.setBounds(220, 200, 150,20);
		this.add(txtBirthYear);
		
		HomeTown = new JLabel("Home Town :");
		HomeTown.setBounds(130, 230, 75,20);
		this.add(HomeTown);
		
		txtHomeTown = new JTextField();
		txtHomeTown.setBounds(220, 230, 150,20);
		this.add(txtHomeTown);
		
		Occupation = new JLabel("Occupation :");
		Occupation.setBounds(130, 260, 75,20);
		this.add(Occupation);
		
		txtOccupation = new JTextField();
		txtOccupation.setBounds(220, 260, 150,20);
		this.add(txtOccupation);
		
		PhoneNo = new JLabel("Phone No.    :");
		PhoneNo.setBounds(130, 290, 75,20);
		this.add(PhoneNo);
		
		txtPhoneNo = new JTextField();
		txtPhoneNo.setBounds(220, 290, 150,20);
		this.add(txtPhoneNo);
		
		
		
		SignUp = new JButton("Sign Up");
		SignUp.setBounds(220, 320, 100,20);
		SignUp.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				if(!(txtPassword.getText().equals(txtCheckPassword.getText())))
				{
					JOptionPane.showMessageDialog(null, "Password did not Match");
					return;
				}
				
				if(!isValidData())
				{
					return;
				}
				if(InsertMember())
				{
					JOptionPane.showMessageDialog(null, "congratulation ! You are in Admin panel");
					//System.exit(0);
					LoginPage plp = new LoginPage();
					plp.setVisible(true);
					closeframe();
				}
				
			}
		});
		this.add(SignUp);

	}
	
	private void closeframe()
	{
		super.dispose();
	}
	public  boolean InsertMember()
	{
		PreparedStatement myPreparedStatement = null;
		
		try
		{
			myPreparedStatement = myCon.prepareStatement("Insert into admins values(?,?,?,?,?,?,?,?)");
			
			myPreparedStatement.setInt(1,Integer.parseInt(txtAccessNo.getText()));
			myPreparedStatement.setString(2,txtUserName.getText() );
			myPreparedStatement.setString(3,txtPassword.getText() );
			myPreparedStatement.setString(4,txtName.getText() );
			myPreparedStatement.setString(5, txtBirthYear.getText());
			myPreparedStatement.setString(6, txtHomeTown.getText());
			myPreparedStatement.setString(7, txtOccupation.getText());
			myPreparedStatement.setString(8, txtPhoneNo.getText());
			
			int i = myPreparedStatement.executeUpdate();
			
			return i>0;
		}
		catch(Exception e)
		{
			JOptionPane.showMessageDialog(null, e.getMessage());
		}
		finally
		{
			close(null,myPreparedStatement,null);
		}
		return false;
	}
	private void close(Statement myStatement,PreparedStatement preparedStatement , ResultSet myResultSet) {
	try
	{
		if(myStatement!=null)
			myStatement.close();
		if(preparedStatement!=null)
			preparedStatement.close();
		if(myResultSet!=null)
			myResultSet.close();
		
	}
	catch(Exception e)
	{
		JOptionPane.showMessageDialog(null, e.getMessage());
	}
	
	}
	
	
	private boolean isValidData()
	{
		if(!ValidationHelper.isIntValid(txtAccessNo.getText()))
		{
			JOptionPane.showMessageDialog(null, "Invalid Access no");
			return false;
		}
		if(txtName.getText().isEmpty())
		{
			JOptionPane.showMessageDialog(null, "Invalid Name");
			return false;
		}
		if(txtBirthYear.getText().isEmpty())
		{
			JOptionPane.showMessageDialog(null, "Invalid Birth Year");
			return false;
		}
		if(txtHomeTown.getText().isEmpty())
		{
			JOptionPane.showMessageDialog(null, "Invalid Home Town");
			return false;
		}
		if(txtOccupation.getText().isEmpty())
		{
			JOptionPane.showMessageDialog(null, "Invalid Occupation");
			return false;
		}
		if(txtPhoneNo.getText().isEmpty())
		{
			JOptionPane.showMessageDialog(null, "Invalid Phone No");
			return false;
		}
		if(txtPassword.getText().isEmpty())
		{
			JOptionPane.showMessageDialog(null, "Invalid password");
			return false;
		}
		if(txtCheckPassword.getText().isEmpty())
		{
			JOptionPane.showMessageDialog(null, "Invalid check password");
			return false;
		}
		return true;
	}
	

}
