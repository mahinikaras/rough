package GUILayer;

public class projectMain {

	
	public static void main(String[] args) {
		
		HomePage hp = new HomePage();
		hp.setVisible(true);
	
	}

}
