package GUILayer;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;

import DAOLayer.MemberDAO;
import EntityLayer.Member;
import TableModelLayer.MemberTableModel;

public class DeleteMember extends JFrame {


	private JTable tblMember;
	private MemberDAO memberDAO;
	private JButton Delete;
	
	public DeleteMember()
	{
		   this.setTitle("Meal Management");
		   this.setSize(550,550);
		   this.setLocationRelativeTo(null);
		   this.setLayout(null);
		   //this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		   //this.addpostLoginPageComponent();
		   try
			{
				memberDAO = new MemberDAO();
			}
			catch(Exception e)
			{
				System.out.println(e);
			}
		   tblMember = new JTable();
		   tblMember.setBackground(Color.white);
		    JScrollPane sp = new JScrollPane();
		    sp.setBounds(5,15,520,420);
		    this.add(sp);
		    sp.setViewportView(tblMember);
		    
		    Delete = new JButton("Delete");
		    Delete.setBounds(190, 440, 150, 30);
		    Delete.addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					DeleteData();
					
				}

			});
		    this.add(Delete);
		    
		    this.populateTable();
	}
	
	

	private void DeleteData()
	{
		int row = tblMember.getSelectedRow();
		if(row<0)
			{
			JOptionPane.showMessageDialog(null, "Please select a row");
			return;
			}
		int id = (int)tblMember.getValueAt(row,0);
		if(memberDAO.DeleteMember(id))
		{
			JOptionPane.showMessageDialog(null, "Deleted Successfully");
		}
		else 
			JOptionPane.showMessageDialog(null, "Something Goes Wrong ");
		
		this.populateTable();
			
	}
	private void populateTable() {
		ArrayList<Member> m = new ArrayList<Member>();
		m = memberDAO.GetAllMember();
		MemberTableModel memberTableModel = new MemberTableModel(m);
		tblMember.setModel(memberTableModel);
		
	}
}
