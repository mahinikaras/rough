package GUILayer;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;

import DAOLayer.MealUpdateDAO;
import EntityLayer.MealUpdate;
import HelperLayer.ValidationHelper;
import TableModelLayer.MealUpdateTableModel;
import TableModelLayer.MemberTableModel;

public class updateMealDB extends JFrame{

	Connection myCon;
	JTable tblMealUpdate;
	MealUpdateDAO mealUpdateDAO;
	MemberTableModel memberTableModel;
	JButton Add,Refresh;
	JLabel Date,Dipon,Mahin,Rahat,Shurid,Sajid,Tanim,Tonmoy,Total;
	JTextField txtDate,txtDipon,txtMahin,txtRahat,txtShurid,txtSajid,txtTanim,txtTonmoy;
	JTextField totalDipon,totalMahin,totalRahat,totalShurid,totalSajid,totalTanim,totalTonmoy;
	
	
	
	public updateMealDB(){
		
		try {
			myCon=DriverManager.getConnection("jdbc:mysql://localhost:3306/meal management", "root", "");
		} 
		catch (Exception e) {
			JOptionPane.showMessageDialog(null, "Connection unsuccesful");
		}
	 this.setTitle("Meal Management");
	   this.setSize(600,600);
	   this.setLocationRelativeTo(null);
	   this.setLayout(null);
       this.addupdateMealDBComponent();
	}
	   
	private void addupdateMealDBComponent()
	   
	{
		Date = new JLabel("Date");
	   Date.setBounds(5, 15, 30, 40);
	   this.add(Date);
	   
	   txtDate = new JTextField();
	   txtDate.setBounds(5, 55, 30, 20);
	   this.add(txtDate);
	   
	   Dipon = new JLabel("Dipon");
	   Dipon.setBounds(80, 15, 50, 40);
	   this.add(Dipon);
	   
	   txtDipon = new JTextField();
	   txtDipon.setBounds(80, 55, 30, 20);
	   this.add(txtDipon);
	   
	   Mahin = new JLabel("Mahin");
	   Mahin.setBounds(150, 15, 50, 40);
	   this.add(Mahin);
	   
	   txtMahin = new JTextField();
	   txtMahin.setBounds(150, 55, 30, 20);
	   this.add(txtMahin);
	   
	   Rahat = new JLabel("Rahat");
	   Rahat.setBounds(225, 15, 50, 40);
	   this.add(Rahat);
	   
	   txtRahat = new JTextField();
	   txtRahat.setBounds(225, 55, 30, 20);
	   this.add(txtRahat);
	   
	   Shurid = new JLabel("Shurid");
	   Shurid.setBounds(300, 15, 50, 40);
	   this.add(Shurid);
	   
	   txtShurid = new JTextField();
	   txtShurid.setBounds(300, 55, 30, 20);
	   this.add(txtShurid);
	   
	   Sajid = new JLabel("Sajid");
	   Sajid.setBounds(365, 15, 50, 40);
	   this.add(Sajid);
	   
	   txtSajid = new JTextField();
	   txtSajid.setBounds(365, 55, 30, 20);
	   this.add(txtSajid);
	   
	   Tanim = new JLabel("Tanim");
	   Tanim.setBounds(440, 15, 50, 40);
	   this.add(Tanim);
	   
	   txtTanim = new JTextField();
	   txtTanim.setBounds(440, 55, 30, 20);
	   this.add(txtTanim);
	   
	   Tonmoy = new JLabel("Tonmoy");
	   Tonmoy.setBounds(515, 15, 50, 40);
	   this.add(Tonmoy);
	   
	   txtTonmoy = new JTextField();
	   txtTonmoy.setBounds(515, 55, 30, 20);
	   this.add(txtTonmoy);
	   
	   totalDipon = new JTextField();
	   totalDipon.setBounds(80, 425, 30, 20);
	   totalDipon.setEditable(false);
	   this.add(totalDipon);
	   
	   totalMahin = new JTextField();
	   totalMahin.setBounds(150, 425, 30, 20);
	   totalMahin.setEditable(false);
	   this.add(totalMahin);
	   
	   totalRahat = new JTextField();
	   totalRahat.setBounds(225, 425, 30, 20);
	   totalRahat.setEditable(false);
	   this.add(totalRahat);
	   
	   totalShurid = new JTextField();
	   totalShurid.setBounds(300, 425, 30, 20);
	   totalShurid.setEditable(false);
	   this.add(totalShurid);
	   
	   totalSajid = new JTextField();
	   totalSajid.setBounds(365, 425, 30, 20);
	   totalSajid.setEditable(false);
	   this.add(totalSajid);
	   
	   totalTanim = new JTextField();
	   totalTanim.setBounds(440, 425, 30, 20);
	   totalTanim.setEditable(false);
	   this.add(totalTanim);
	   
	   totalTonmoy = new JTextField();
	   totalTonmoy.setBounds(515, 425, 30, 20);
	   totalTonmoy.setEditable(false);
	   this.add(totalTonmoy);
	   
	   tblMealUpdate = new JTable();
	   tblMealUpdate.setBackground(Color.white);
	    JScrollPane sp = new JScrollPane();
	    sp.setBounds(5,135,570,290);
	    this.add(sp);
	    sp.setViewportView(tblMealUpdate);
	    

	   
	   Add = new JButton("Add");
	   Add.setBounds(220, 95, 110, 20);
	   Add.addActionListener(new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent e) {

			
			
			if(!isValidData())
			{
			return;
			}
			
			if(InsertMember())
			{
				JOptionPane.showMessageDialog(null, "Meal Updated  successfully");
				populateTable();
			}
			try
			{
		    String sql = "Select sum(Dipon) from mealupdate";
		    PreparedStatement myPreparedStatement2=myCon.prepareStatement(sql);
		    ResultSet myResultSet=myPreparedStatement2.executeQuery();
		    if(myResultSet.next())
		    {
		    	String s = myResultSet.getString("sum(dipon)");
		    	totalDipon.setText(s);
		    }
			}
			catch(Exception ex)
			{
				JOptionPane.showMessageDialog(null, ex.getMessage());
			}
			try
			{
		    String sql = "Select sum(Mahin) from mealupdate";
		    PreparedStatement myPreparedStatement2=myCon.prepareStatement(sql);
		    ResultSet myResultSet=myPreparedStatement2.executeQuery();
		    if(myResultSet.next())
		    {
		    	String s = myResultSet.getString("sum(Mahin)");
		    	totalMahin.setText(s);
		    }
			}
			catch(Exception ex)
			{
				JOptionPane.showMessageDialog(null, ex.getMessage());
			}
			try
			{
		    String sql = "Select sum(Rahat) from mealupdate";
		    PreparedStatement myPreparedStatement2=myCon.prepareStatement(sql);
		    ResultSet myResultSet=myPreparedStatement2.executeQuery();
		    if(myResultSet.next())
		    {
		    	String s = myResultSet.getString("sum(Rahat)");
		    	totalRahat.setText(s);
		    }
			}
			catch(Exception ex)
			{
				JOptionPane.showMessageDialog(null, ex.getMessage());
			}
			try
			{
		    String sql = "Select sum(Shurid) from mealupdate";
		    PreparedStatement myPreparedStatement2=myCon.prepareStatement(sql);
		    ResultSet myResultSet=myPreparedStatement2.executeQuery();
		    if(myResultSet.next())
		    {
		    	String s = myResultSet.getString("sum(Shurid)");
		    	totalShurid.setText(s);
		    }
			}
			catch(Exception ex)
			{
				JOptionPane.showMessageDialog(null, ex.getMessage());
			}
			try
			{
		    String sql = "Select sum(Sajid) from mealupdate";
		    PreparedStatement myPreparedStatement2=myCon.prepareStatement(sql);
		    ResultSet myResultSet=myPreparedStatement2.executeQuery();
		    if(myResultSet.next())
		    {
		    	String s = myResultSet.getString("sum(Sajid)");
		    	totalSajid.setText(s);
		    }
			}
			catch(Exception ex)
			{
				JOptionPane.showMessageDialog(null, ex.getMessage());
			}
			try
			{
		    String sql = "Select sum(Tanim) from mealupdate";
		    PreparedStatement myPreparedStatement2=myCon.prepareStatement(sql);
		    ResultSet myResultSet=myPreparedStatement2.executeQuery();
		    if(myResultSet.next())
		    {
		    	String s = myResultSet.getString("sum(Tanim)");
		    	totalTanim.setText(s);
		    }
			}
			catch(Exception ex)
			{
				JOptionPane.showMessageDialog(null, ex.getMessage());
			}
			try
			{
		    String sql = "Select sum(Tonmoy) from mealupdate";
		    PreparedStatement myPreparedStatement2=myCon.prepareStatement(sql);
		    ResultSet myResultSet=myPreparedStatement2.executeQuery();
		    if(myResultSet.next())
		    {
		    	String s = myResultSet.getString("sum(Tonmoy)");
		    	totalTonmoy.setText(s);
		    }
			}
			catch(Exception ex)
			{
				JOptionPane.showMessageDialog(null, ex.getMessage());
			}
//			try
//			{
//			String d = calculateTotal(1);
//			totalDipon.setText(d);
//			String m = calculateTotal(2);
//			totalMahin.setText(m);
//			String r = calculateTotal(3);
//			totalRahat.setText(r);
//			String sh = calculateTotal(4);
//			totalShurid.setText(sh);
//			String sa = calculateTotal(5);
//			totalSajid.setText(sa);
//			String ta = calculateTotal(6);
//			totalTanim.setText(ta);
//			String to = calculateTotal(7);
//			totalTonmoy.setText(to);
//			}
//			catch(Exception ex)
//			{
//				JOptionPane.showMessageDialog(null, ex.getMessage());
//			}
			
		}
	});
	   this.add(Add);
	   
	   
	 this.populateTable();
}
	

//	public String  calculateTotal(int column)
//	{
//		int total = 0;
//	    for (int i = 0; i < memberTableModel.getRowCount(); i++){
//	        int amount = Integer.parseInt((String) memberTableModel.getValueAt(i, column));
//	        total += amount;
//	    }
//	    
//		String s=Integer.toString(total);
//		return s;
//		
//				
//	}
	
	

	public  boolean InsertMember()
	{
		PreparedStatement myPreparedStatement = null;
		
		try
		{
			
			
			myPreparedStatement = myCon.prepareStatement("Insert into mealupdate values(?,?,?,?,?,?,?,?)");
			
			myPreparedStatement.setInt(1,Integer.parseInt(txtDate.getText()));
			myPreparedStatement.setInt(2,Integer.parseInt(txtDipon.getText()) );
			myPreparedStatement.setInt(3,Integer.parseInt(txtMahin.getText()) );
			myPreparedStatement.setInt(4,Integer.parseInt(txtRahat.getText()) );
			myPreparedStatement.setInt(5, Integer.parseInt(txtShurid.getText()));
			myPreparedStatement.setInt(6, Integer.parseInt(txtSajid.getText()));
			myPreparedStatement.setInt(7, Integer.parseInt(txtTanim.getText()));
			myPreparedStatement.setInt(8, Integer.parseInt(txtTonmoy.getText()));
			
			int i = myPreparedStatement.executeUpdate();
			
			
			
			return i>0;
		}
		catch(Exception e)
		{
			JOptionPane.showMessageDialog(null, e.getMessage());
		}
		finally
		{
			close(null,myPreparedStatement,null);
		}
		return false;
	}
	private void close(Statement myStatement,PreparedStatement preparedStatement , ResultSet myResultSet) {
	try
	{
		if(myStatement!=null)
			myStatement.close();
		if(preparedStatement!=null)
			preparedStatement.close();
		if(myResultSet!=null)
			myResultSet.close();
		
	}
	catch(Exception e)
	{
		JOptionPane.showMessageDialog(null, e.getMessage());
	}
	
	}
	
	private boolean isValidData()
	{
		if(!ValidationHelper.isIntValid(txtDate.getText()))
		{
			JOptionPane.showMessageDialog(null, "Invalid Date");
			return false;
		}
		if(!ValidationHelper.isIntValid(txtDipon.getText()))
		{
			JOptionPane.showMessageDialog(null, "Invalid Dipon");
			return false;
		}
		if(!ValidationHelper.isIntValid(txtMahin.getText()))
		{
			JOptionPane.showMessageDialog(null, "Invalid Mahin");
			return false;
		}
		if(!ValidationHelper.isIntValid(txtRahat.getText()))
		{
			JOptionPane.showMessageDialog(null, "Invalid rahat");
			return false;
		}
		if(!ValidationHelper.isIntValid(txtShurid.getText()))
		{
			JOptionPane.showMessageDialog(null, "Invalid shurid");
			return false;
		}
		if(!ValidationHelper.isIntValid(txtSajid.getText()))
		{
			JOptionPane.showMessageDialog(null, "Invalid sajid");
			return false;
		}
		if(!ValidationHelper.isIntValid(txtTanim.getText()))
		{
			JOptionPane.showMessageDialog(null, "Invalid tanim");
			return false;
		}
		if(!ValidationHelper.isIntValid(txtTonmoy.getText()))
		{
			JOptionPane.showMessageDialog(null, "Invalid tonmoy");
			return false;
		}
		
		return true;
	}

private void populateTable() {
	mealUpdateDAO = new MealUpdateDAO();
	ArrayList<MealUpdate> m = new ArrayList<MealUpdate>();
	m = mealUpdateDAO.GetAllMealUpdate();
	MealUpdateTableModel MealUpdateTableModel = new MealUpdateTableModel(m);
	tblMealUpdate.setModel(MealUpdateTableModel);
	}


}

