package GUILayer;



import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.Timer;



public class HomePage extends JFrame{

	JButton Login,Signup;
	JLabel CreateNewAcc,MovingText;
	JCheckBox RPwCheck;
	Timer MovingTextTimer;
	
	public HomePage()
	{
		   this.setTitle("Meal Management");
		   this.setSize(500,500);
		   this.setLocationRelativeTo(null);
		   this.setLayout(null);
		   this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		   this.addHomePageComponent();
		   //this.addKeyListener(new keyHandler());
		   //this.setFocusable(true);
	}

	private void addHomePageComponent() {
		
	   Login = new JButton("Log In");
	   Login.setBounds(190, 180, 100,20);
	   Login.addActionListener(new HomePageHandler());
	   this.add(Login);
	   
	   Signup = new JButton("Sign Up");
	   Signup.setBounds(190, 220, 100,20);
	   Signup.addActionListener(new HomePageHandler());
	   this.add(Signup);

	   CreateNewAcc = new JLabel("( Create An Account )");
	   CreateNewAcc.setBounds(300, 220,200, 20);
	   this.add(CreateNewAcc);
	   
	   MovingText = new JLabel("Meal Management System .. ");
	   MovingText.setBounds(150, 400, 200, 40);
	   this.add(MovingText);
	   
	   MovingTextTimer = new Timer(100, new HomePageHandler());
	   MovingTextTimer.start();
	   
	  }
	
	private class HomePageHandler implements ActionListener
	{

		@Override
		public void actionPerformed(ActionEvent e) {
			if (e.getSource()== MovingTextTimer)
			{
//				int x = MovingText.getX();
//			    int y = MovingText.getY();
//			    int w = MovingText.getWidth();
//			  if((x+ w)> 400)
//			{
//					MovingText.setBounds(100,400, 200, 40);
//			}
//				
//				x = x+5;
//				MovingText.setBounds(x,y, 200, 40);
				String oldText = MovingText.getText();
			    String newText = oldText.substring(1) + oldText.substring(0, 1);
			    MovingText.setText(newText );
			}
			
			if(e.getSource()== Login)
			{
				LoginPage lp1 = new LoginPage();
				lp1.setVisible(true);
			}
			
			if(e.getSource()== Signup)
			{
				SignUpPage sup1 = new SignUpPage();
				sup1.setVisible(true);
			}
			
		}
		
	}
}
