package GUILayer;

import java.awt.Color;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;

import TableModelLayer.MemberTableModel;
import DAOLayer.MemberDAO;
import EntityLayer.Member;

public class MemberList extends JFrame {
	

	private JTable tblMember;
	private MemberDAO memberDAO;
	
	public MemberList()
	{
		   this.setTitle("Meal Management");
		   this.setSize(550,550);
		   this.setLocationRelativeTo(null);
		   this.setLayout(null);
		   //this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		   //this.addpostLoginPageComponent();
		   try
			{
				memberDAO = new MemberDAO();
			}
			catch(Exception e)
			{
				System.out.println(e);
			}
		   tblMember = new JTable();
		   tblMember.setBackground(Color.white);
		    JScrollPane sp = new JScrollPane();
		    sp.setBounds(5,15,520,480);
		    this.add(sp);
		    sp.setViewportView(tblMember);
		    
		    this.populateTable();
	}

	private void populateTable() {
		ArrayList<Member> m = new ArrayList<Member>();
		m = memberDAO.GetAllMember();
		MemberTableModel memberTableModel = new MemberTableModel(m);
		tblMember.setModel(memberTableModel);
		
	}

}
