package GUILayer;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;

import HelperLayer.LoginHelper;


public class postLoginPage extends JFrame {
JButton ViewMonthlyList,UpdateMeal,DeleteMember,AddMember,LogOut,MemberList;
	
	public postLoginPage()
	{
		   this.setTitle("Meal Management");
		   this.setSize(500,500);
		   this.setLocationRelativeTo(null);
		   this.setLayout(null);
		   //this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		   this.addpostLoginPageComponent();
		   //this.addKeyListener(new keyHandler());
		   //this.setFocusable(true);
	}

	private void addpostLoginPageComponent() {
		
		MemberList = new JButton("Member List");
		MemberList.setBounds(175, 120, 130,20);
		MemberList.addActionListener(new  ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				MemberList ml = new MemberList();
				ml.setVisible(true);
				
			}
		});
		this.add(MemberList);
		
		ViewMonthlyList = new JButton("Monthly List");
		ViewMonthlyList.setBounds(175, 150, 130,20);
		//ViewMonthlyList.addActionListener(new postLoginPageHandler());
		this.add(ViewMonthlyList);
		
		UpdateMeal = new JButton("Update meal");
		UpdateMeal.setBounds(175, 180, 130,20);
		UpdateMeal.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				updateMealDB umd = new updateMealDB();
				umd.setVisible(true);
				
			}
		});
		this.add(UpdateMeal);
		
		AddMember = new JButton("Add Member");
		AddMember.setBounds(175, 210, 130,20);
		AddMember.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				AddMember am = new AddMember();
				am.setVisible(true);
				
			}
		});
		this.add(AddMember);
		
		DeleteMember = new JButton("Delete Member");
		DeleteMember.setBounds(175, 240, 130,20);
		DeleteMember.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				DeleteMember dm = new DeleteMember();
				dm.setVisible(true);
				
			}
		});
		this.add(DeleteMember);
		
		LogOut = new JButton("Log Out");
		LogOut.setBounds(175, 270, 130,20);
		LogOut.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				LoginHelper.loginuser=null;
				closeframe();
				HomePage hp = new HomePage();
				hp.setVisible(true);
				
			}
		});
		this.add(LogOut);
	
	}
	private void closeframe()
	{
		super.dispose();
	}
		
	}

