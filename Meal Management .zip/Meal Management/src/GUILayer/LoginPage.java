package GUILayer;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import DAOLayer.adminsDAO;
import EntityLayer.Admins;
import HelperLayer.LoginHelper;



public class LoginPage extends JFrame{

	private Admins admins;
	private adminsDAO adminsdao;
	JButton Login;
	JLabel UserName,Password,AccessNO;
	JPasswordField txtPassword,txtAccessNO;
	JTextField txtUserName;
	
	public LoginPage()
	{
		adminsdao = new adminsDAO();
		this.setTitle("Meal Management");
		   this.setSize(500,500);
		   this.setLocationRelativeTo(null);
		   this.setLayout(null);
		   //this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		   this.addLoginPageComponent();
		   //this.addKeyListener(new keyHandler());
		   //this.setFocusable(true);
	}

	private void addLoginPageComponent() {

		
		UserName = new JLabel("User Name");
		UserName.setBounds(130, 150, 70,20);
		this.add(UserName);
		
		txtUserName = new JTextField();
		txtUserName.setBounds(220, 150, 150,20);
		this.add(txtUserName);
		
		Password = new JLabel("Password");
		Password.setBounds(130, 180, 70,20);
		this.add(Password);
		
		txtPassword = new JPasswordField();
		txtPassword.setBounds(220, 180, 150, 20);
		this.add(txtPassword);
		
		Login = new JButton("Log In");
		Login.setBounds(220, 220, 70,20);
		Login.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				
				admins=adminsdao.Login(txtUserName.getText(), txtPassword.getText());
				if(admins.getAccessNo()==-1)
				{
					JOptionPane.showMessageDialog(null, "invalid  Username and Password");
				}
				else
				{
					LoginHelper.loginuser=admins;
					
					postLoginPage plp = new postLoginPage();
					plp.setVisible(true);
					closeframe();
				}
				
				
			}
		});
		this.add(Login);

	}
	private void closeframe()
	{
		super.dispose();
	}
}
