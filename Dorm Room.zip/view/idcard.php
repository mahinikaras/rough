<?php
session_start();
if(empty($_SESSION['lastName'])  )
{
	header("location:login.html");

}
include("header.php");

?>
<html>
<head>
		<title>HOME</title>
		<link rel="stylesheet" href="dormHome.css"/>
	
</head>
</body>
<form method="post" action="../controller/idcardcheck.php" enctype="multipart/form-data">
<div id="content" style="width:72.5% ; height:100% ;">
				<fieldset>
    <legend><b>PICTURE OF VARSITY ID CARD</b></legend>
    
        <img width="200" height="200" src="../idpics/<?=$_SESSION['lastName'].$_SESSION['userType']?>"/>
        <br />
        <input type="file" name="idcard">
        <hr />
        <input type="submit" value="Submit">
    
</fieldset>
<div style="margin-top:90px ;margin-left:400px">
			<img width="300" height="200" src="../idpics/<?=$_SESSION['lastName'].$_SESSION['userType']?>"/>
		</div>
			</div>
		
	
	</body>


</html>