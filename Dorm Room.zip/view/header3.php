<?php
error_reporting(0);
session_start();
if(empty($_SESSION['lastName']) )
{
	header("location:login.html");

}

$userName=$_GET['userName'];
$suserName=$_SESSION['userName'];
$dbservername ="localhost";
	$dbusername ="root";
	$dbpassword ="";
	$dbname ="dormroom";
	$conn = mysqli_connect($dbservername, $dbusername, $dbpassword, $dbname);
	if(!$conn){
			die("Connection Error!".mysqli_connect_error());
	}
	$sql = "select * from alluser where userName='$userName'";
								if($result=mysqli_query($conn, $sql)){
								while($row=mysqli_fetch_assoc($result))
								{
									$university = $row['university'];
									$universityId = $row['universityId'];
									$department = $row['department'];
									$dob=$row['dob'];
	 
								}
							}else{
									echo "<br/> Something Wrong".mysqli_error($conn);
								}

								?>



<html>
	<head>
		<title>HOME</title>
		<link rel="stylesheet" href="dormHome.css"/>
	
	</head>
	<body>
		<div id="head" align="right" style="width:100%; background-image: linear-gradient(to bottom, #b4b2cb, #9391a6, #747283, #555461, #393841);">
			<!-- <a href="help.php">help</a> -->
			<a href="settings.php">settings</a>
			
			<a href="home.php">home</a>
			<a href="login.html">logout</a>
			
			
			<form id="form" style="margin-top:-10px;">
				<input type="text" placeholder="search here"/>
				<input type="submit" value="search"/>
			</form>
			<div id="logo">
				<img src="logo.jpg" width="50px" height="40px" align="left">
			</div>
			<div id="id">
				
				<div id="image">
					
					<?php
					  $con=mysqli_connect("localhost","root","","dormroom");
                      // $username = $_SESSION['userName'];
                        $sql = "select * from images where userName='$suserName'and photoType='propic' order by id desc" ;
                       $query = mysqli_query($con, $sql);
                       $num = mysqli_num_rows($query);
                       for($i=0; $i<1; $i++){
                           $result = mysqli_fetch_array($query);
                           $img = $result['image'];
                           echo '<a href="userpersonalprofile.php"><img src="data:image;base64,'.$img.'" style="height:40px ;width:40px;" /> </a>';
                       }
					  ?>


					<!-- <img src="../propics/<?=$_SESSION['userName']?>" width="40px" height="40px"></a> -->
				</div>
				<div id="name">
					<?php echo $_SESSION['userName']?>
				</div>
				
			</div>
			
		</div>

		<div id="body" style="width:100%; height:100%; background-image: white;">
			
			<div id="left" style="height:100%; background-image: linear-gradient(to right bottom, #b4b2cb, #9391a6, #747283, #555461, #393841);">
				<div id="bigProfilePic" name="bigProfilePic" style="display:none;background-color: white;border:1px solid black;height: 500px;width: 500px;position:fixed;margin-left:650px;margin-top:90px;">
					<input type="button" id="imageCloseButton" name="imageCloseButton" value="x" style="float:right;margin-top:8px;margin-right: 8px;border-radius: 15px" onclick="closeImage()">
					<center>
						<?php
					  $con=mysqli_connect("localhost","root","","dormroom");
                      // $username = $_SESSION['userName'];
                        $sql = "select * from images where userName='$userName'and photoType='propic' order by id desc" ;
                       $query = mysqli_query($con, $sql);
                       $num = mysqli_num_rows($query);
                       for($i=0; $i<1; $i++){
                           $result = mysqli_fetch_array($query);
                           $img = $result['image'];
                           echo '<img src="data:image;base64,'.$img.'" style="height:360px ;width:360px;margin:25px;margin-top: 60px" /> ';
                       }
					  ?>

					

			</div>	
				<ul>
					<li><a href="campus.php">campus</a></li>
					<li>library</li>
					
					<li><a href="newspaper.php">newspaper</a></li>
					<li><a href="chatbox.php">Chatbox</a></li>
					<li><a href="day.php">My day</a></li>
					<li><a href="idcard.php">ID card</a></li>
				</ul>
				<center>

					<?php
					  $con=mysqli_connect("localhost","root","","dormroom");
                      // $username = $_SESSION['userName'];
                        $sql = "select * from images where userName='$userName'and photoType='propic' order by id desc" ;
                       $query = mysqli_query($con, $sql);
                       $num = mysqli_num_rows($query);
                       for($i=0; $i<1; $i++){
                           $result = mysqli_fetch_array($query);
                           $img = $result['image'];
                           echo '<img src="data:image;base64,'.$img.'" width="90px" height="100px" onclick="image()"/> ';

                       }
					  ?>

					<!-- <img src="../propics/<?=$_GET['userName']?>" height=100px width=90px onclick="image()"> -->
				</center>
				<!-- <center><h3><a href="changepic.php"> </a></h3><br/></center> -->
				<center>university  : <?=$university?><br/>
				universityID : <?=$universityId?><br/>
				Department : <?=$department?><br/>
				dob : <?=$dob?></center><br/>
				<div style="">
				<center>

					<?php
					  $con=mysqli_connect("localhost","root","","dormroom");
                      // $username = $_SESSION['userName'];
                        $sql = "select * from images where userName='$userName'and photoType='myday' order by id desc" ;
                       $query = mysqli_query($con, $sql);
                       $num = mysqli_num_rows($query);
                       for($i=0; $i<1; $i++){
                           $result = mysqli_fetch_array($query);
                           $img = $result['image'];
                           echo '<img src="data:image;base64,'.$img.'" width="140px" height="200px" "/> ';
                       }
					  ?>

					<!-- <img src="../day/<?=$_GET['userName']?>" height=200px width=140px style="margin-top: 50px;margin-right: 26px" alt="upload your day" /> -->
					<h4 style="margin-top:10px;margin-right: 25px">My Day</h4>

				</center>



				</div>
			</div>
			<script>
				function image()
				{
					document.getElementById("bigProfilePic").style.display="block";
				}
				function closeImage()
				{
					document.getElementById("bigProfilePic").style.display="none";
				}
			</script>

