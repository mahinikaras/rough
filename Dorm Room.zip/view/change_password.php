<?php

session_start();
if(empty($_SESSION['lastName']) )
{
	header("location:login.html");
	

}
include("header.php");
echo '
<head>
		<title>HOME</title>
		<link rel="stylesheet" href="dormHome.css"/>
	
</head>
<center>
	<form method="post" action="../controller/pcheck.php">
		<table border="0" cellspacing="0" cellpadding="5">
			<tr>
				<td>
					<fieldset style="margin:30%">
						<legend>CHANGE PASSWORD</legend>
						Current Password<br />
						<input type="password" name="cpass" /><br />
						New Password<br />
						<input type="password" name="npass" /><br />
						Retype New Password<br />
						<input type="password" name="rpass"/>								
						<hr />
						<input type="submit" value="Change" name="submit"/>   
                         <a href="home.php">Home</a>
						
					</fieldset>
				</td>
			</tr>
		</table>
	</form>
</center>';

?>
