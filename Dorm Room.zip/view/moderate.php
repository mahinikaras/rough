<?php
session_start();
if(empty($_SESSION['lastName']) || $_SESSION['userType'] != "admin" )
{
	header("location:login.html");

}
include("header.php");
echo '<head>
		<title>HOME</title>
		<link rel="stylesheet" href="dormHome.css"/>
	
</head>';
	echo '<div id="content" style="width:72.5% ; height:100%">
				<ul>
					<li><a href="viewUser.php">view User</a></li>
					<li><a href="deleteUser.php">Delete User</a></li>
					<li><a href="updateUser.php">Update User</a></li>
					
					
				</ul>
			</div>';
?>
