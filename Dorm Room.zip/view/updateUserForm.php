<?php
	session_start();
	if(empty($_SESSION['lastName']) )
	{
		header("location:login.html");

	}
	include("header.php"); 

	$id=$_GET['id'];

	   				$conn = mysqli_connect('localhost', 'root', '', 'dormroom');
                     $sql = "select * from alluser where id='$id'";
                     $result = mysqli_query($conn, $sql);

					while ($row = mysqli_fetch_assoc($result)) 
					{
						$firstName = $row['firstName'];
						$lastName=$row['lastName'];
						$userName=$row['userName'];
						$emailId=$row['emailId'];
						$password=$row['password'];
						$dob=$row['dob'];
						$university=$row['university'];
						$universityId=$row['universityId'];
						$department=$row['department'];
						$gender=$row['gender'];
						$userType=$row['userType'];
					}

?>

<head>
		<title>HOME</title>
		<link rel="stylesheet" href="dormHome.css"/>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <link href="https://fonts.googleapis.com/css?family=Lobster" rel="stylesheet" type="text/css">
	
</head>
	<div id="content" style="width:72.5% ; height:100%">
		<form action="../controller/updateUserController.php?id=<?=$id?>" method="post" onsubmit="return validateForm()">
			<center><div style="margin-left:% ; margin-top:%">
				
        		<table>
        			<tr>
        				<th></th>
        				<th></th>
                        <th></th>
        			</tr>
        			<tr><td><br/></td></tr>
        			<tr>
		        		<td>First name :</td>
		        		<td><input type="text" name="firstname" id="firstname" value="<?=$firstName?>" onkeyup="firstNameValidation()" onblur="document.getElementById('firstNameMsg').innerHTML= '';"/></td>
                        <td id="firstNameMsg"></td>
			        </tr>
			        <tr><td><br/></td></tr>
			        <tr>
		        		<td>Last name :</td>
		        		<td><input type="text" name="lastname"  id="lastname"	value="<?=$lastName?>" onkeyup="lastNameValidation()" onblur="document.getElementById('lastNameMsg').innerHTML= '';" /></td>
                        <td id="lastNameMsg"></td>
			        </tr>
			        <tr><td><br/></td></tr>
			        <tr>
		        		<td>User name :</td>
		        		<td><input type="text" name="username" id="username" 	value="<?=$userName?>"  onkeyup="userNameValidation()" onblur="document.getElementById('userNameMsg').innerHTML= '';"/></td>
                        <td id="userNameMsg"></td>
			        </tr>
			        <tr><td><br/></td></tr>
			        <tr>
		        		<td>Email ID :</td>
		        		<td><input type="text" name="emailid"  id="emailid"	value="<?=$emailId?>" onkeyup="ValidateEmail()" onblur="document.getElementById('emailValidation').innerHTML= '';" /></td>
                        <td id="emailValidation"></td>
			        </tr>
			        <tr><td><br/></td></tr>
			        <tr>
		        		<td>Password :</td>
		        		<td><input type="password" name="password" id="password" 	value="<?=$password?>"  onkeyup="passWordStrength()" onblur="document.getElementById('passWordStrength').innerHTML= '';"/></td>
                        <td id='passWordStrength'></td>
			        </tr>
			         
			         <tr><td><br/></td></tr>
			        <tr>
		        		<td> DOB :</td>
		        		<td><input type="date" name="   dob"  id="dob"	value="<?=$dob?>" style="width: 175px"/></td>
                        <td></td>
			        </tr>
			        <tr><td><br/></td></tr>
			        <tr>
		        		<td> University : </td>
		        		<td> 
		        			<select style="width: 175px" name="University" value="">
		        				  <option value="<?=$university?>" ><?=$university?></option>
								  <option value="Ahsanullah University of Science and Technology" >Ahsanullah University of Science and Technology</option>
								  <option value="American International University-Bangladesh" >American International University-Bangladesh</option>
								  <option value="ASA University Bangladesh" >ASA University Bangladesh</option>
								  <option value="Asian University of Bangladesh" >Asian University of Bangladesh</option>
								  <option value="Atish Dipankar University of Science and Technology" >Atish Dipankar University of Science and Technology</option>
								  <option value="Bangabandhu Sheikh Mujib Medical University" >Bangabandhu Sheikh Mujib Medical University</option>
								  <option value="Bangabandhu Sheikh Mujibur Rahman Agricultural University" >Bangabandhu Sheikh Mujibur Rahman Agricultural University</option>
								  <option value="Bangabandhu Sheikh Mujibur Rahman Maritime University" >Bangabandhu Sheikh Mujibur Rahman Maritime University</option>
								  <option value="Bangabandhu Sheikh Mujibur Rahman Science and Technology University" >Bangabandhu Sheikh Mujibur Rahman Science and Technology University</option>
								  <option value="Bangladesh Agricultural University" >Bangladesh Agricultural University</option>
								  <option value="Bangladesh Islami University" >Bangladesh Islami University</option>
								  <option value="Bangladesh University" >Bangladesh University</option>
								  <option value="Bangladesh University of Business and Technology" >Bangladesh University of Business and Technology</option>
								  <option value="Bangladesh University of Engineering and Technology" > Bangladesh University of Engineering and Technology</option>
								  <option value="Bangladesh University of Professionals" >Bangladesh University of Professionals</option>
								  <option value="Bangladesh University of Textiles" >Bangladesh University of Textiles</option>
								  <option value="Begum Gulchemonara Trust University" >Begum Gulchemonara Trust University</option>
								  <option value="Begum Rokeya University" >Begum Rokeya University</option>
								  <option value="BRAC University" >BRAC University</option>
								  <option value="Chittagong University of Engineering and Technology" >Chittagong University of Engineering and Technology</option>
								  <option value="Chittagong Veterinary and Animal Sciences University" >Chittagong Veterinary and Animal Sciences University</option>
								  <option value="City University" >City University</option>
								  <option value="Comilla University" >Comilla University</option>
								  <option value="Coxs Bazar International University" >Coxs Bazar International University</option>
								  <option value="Daffodil International University" >Daffodil International University</option>
								  <option value="Darul Ihsan University" >Darul Ihsan University</option>
								  <option value="Dhaka International University" >Dhaka International University</option>
								  <option value="Dhaka University of Engineering and Technology" >Dhaka University of Engineering and Technology</option>
								  <option value="East Delta University" >East Delta University</option>
								  <option value="East West University" >East West University</option>
								  <option value="Eastern University, Bangladesh" >Eastern University, Bangladesh</option>
								  <option value="European University of Bangladesh" >European University of Bangladesh</option>
								  <option value="Gono Bishwabidyalay" >Gono Bishwabidyalay</option>
								  <option value="Green University of Bangladesh" >Green University of Bangladesh</option>
								  <option value="Hajee Mohammad Danesh Science and Technology University" >Hajee Mohammad Danesh Science and Technology University</option>
								  <option value="IBAIS University" >IBAIS University</option>
								  <option value="Independent University, Bangladesh" >Independent University, Bangladesh</option>
								  <option value="International Islamic University, Chittagong" >International Islamic University, Chittagong</option>
								  <option value="International University of Business Agriculture and Technology" >International University of Business Agriculture and Technology</option>
								  <option value="Islamic University" >Islamic University</option>
								  <option value="Islamic University of Technology" >Islamic University of Technology</option>
								  <option value="Jagannath University" >Jagannath University</option>
								  <option value="Jahangirnagar University" >Jahangirnagar University</option>
								  <option value="Jatiya Kabi Kazi Nazrul Islam University" >Jatiya Kabi Kazi Nazrul Islam University</option>
								  <option value="Jessore University of Science and Technology" >Jessore University of Science and Technology</option>
								  <option value="Khulna University" >Khulna University</option>
								  <option value="Khulna University of Engineering and Technology" >Khulna University of Engineering and Technology</option>
								  <option value="Khwaja Yunus Ali University" >Khwaja Yunus Ali University</option>
								  <option value="Leading University" >Leading University</option>
								  <option value="Manarat International University" >Manarat International University</option>
								  <option value="Mawlana Bhashani Science and Technology University" >Mawlana Bhashani Science and Technology University</option>
								  <option value="Metropolitan University" >Metropolitan University</option>
								  <option value="National University, Bangladesh" >National University, Bangladesh</option>
								  <option value="Noakhali Science and Technology University" >Noakhali Science and Technology University</option>
								  <option value="North South University" >North South University</option>
								  <option value="North Western University" >North Western University</option>
								  <option value="Northern University of Bangladesh" >Northern University of Bangladesh</option>
								  <option value="Notre Dame University Bangladesh" >Notre Dame University Bangladesh</option>
								  <option value="Pabna Science and Technology University" >Pabna Science and Technology University</option>
								  <option value="Patuakhali Science and Technology University" >Patuakhali Science and Technology University</option>
								  <option value="Port City International University">Port City International University</option>
								  <option value="Premier University" >Premier University</option>
								  <option value="Presidency University, Bangladesh" >Presidency University, Bangladesh</option>
								  <option value="Prime University" >Prime University</option>
								  <option value="Primeasia University" >Primeasia University</option>
								  <option value="Rajshahi University" >Rajshahi University</option>
								  <option value="Rajshahi University of Engineering and Technology" >Rajshahi University of Engineering and Technology</option>
								  <option value="Rangamati University of Science and Technology" >Rangamati University of Science and Technology</option>
								  <option value="Royal University of Dhaka" >Royal University of Dhaka</option>
								  <option value="Shahjalal University of Science and Technology" >Shahjalal University of Science and Technology</option>
								  <option value="Shanto Mariam University of Creative Technology" >Shanto Mariam University of Creative Technology</option>
								  <option value="Sher-e-Bangla Agricultural University" >Sher-e-Bangla Agricultural University</option>
								  <option value="Sonargaon University" >Sonargaon University</option>
								  <option value="Southeast University, Bangladesh" name="University">Southeast University, Bangladesh</option>
								  <option value="Southern University Bangladesh" >Southern University Bangladesh</option>
								  <option value="Stamford University Bangladesh" >Stamford University Bangladesh</option>
								  <option value="State University of Bangladesh" >State University of Bangladesh</option>
								  <option value="Sylhet Agricultural University" >Sylhet Agricultural University</option>
								  <option value="Sylhet International University" >Sylhet International University</option>
								  <option value="The Millenium University" >The Millenium University</option>
								  <option value="The People's University of Bangladesh">The People's University of Bangladesh</option>
								  <option value="The University of Asia Pacific" >The University of Asia Pacific</option>
								  <option value="United International University" >United International University</option>
								  <option value="University of Barisal" >University of Barisal</option>
								  <option value="University of Chittagong" >University of Chittagong</option>
								  <option value="University of Development Alternative" >University of Development Alternative</option>
								  <option value="University of Dhaka" >University of Dhaka</option>
								  <option value="University of Information Technology and Sciences" >University of Information Technology and Sciences</option>
								  <option value="University of Liberal Arts Bangladesh" >University of Liberal Arts Bangladesh</option>
								  <option value="University of Science and Technology Chittagong" >University of Science and Technology Chittagong</option>
								   <option value="University of South Asia, Bangladesh" >University of South Asia, Bangladesh</option>
								  <option value="Uttara University" >Uttara University</option>
								  <option value="Victoria University of Bangladesh" >Victoria University of Bangladesh</option>
								  <option value="World University of Bangladesh" >World University of Bangladesh</option>
							</select> 
						</td>
                        <td></td>
			        </tr>
			        <tr><td><br/></td></tr>
			        <tr>
		        		<td>University ID :</td>
		        		<td><input type="text" name="uniid" id="uniid" value="<?=$universityId?>" onkeyup="uniId()" onblur="document.getElementById('uniId').innerHTML= '';" /></td>
                        <td id='uniId'></td>
			        </tr>
			        <tr><td><br/></td></tr>
			        <tr>
		        		<td>Department :</td>
		        		<td>
		        			<select style="width: 175px" name="department">
		        				<option value="<?=$department?>" ><?=$department?></option>
		        				<option value="cs" >CS</option>
		        				<option value="eee" >EEE</option>
		        				<option value="law" >LAW</option>
		        				<option value="bba" >BBA</option>
		        				<option value="archi" >ARCHI</option>
		        				<option value="english" >ENGLISH</option>
		        			</select>
		        		</td>
			        </tr>
			        <tr><td><br/></td></tr>
			        <tr>
		        		<td>Gender :</td>
		        		<td>
		        			<input type="radio" name="gender" id="gender" value="male" <?php if($gender==male) echo "checked=checked"?> style="width: 30px"/>Male 
		        			<input type="radio" name="gender" id="gender" value="female"  <?php if($gender==female) echo "checked=checked"?>  style="width: 30px"/>Female
		        		</td>
			        </tr>
			         <tr><td><br/></td></tr>
			        <tr>
		        		<td>User Type : <h6> recommended (user) </h6></td>
		        		<td>
		        			<input type="radio" name="usertype" value="cr" <?php if($userType==cr) echo "checked=checked"?> style="width: 4 0px"/>CR
		        			<input type="radio" name="usertype" value="user" <?php if($userType==user) echo "checked=checked"?> style="width: 40px"/>User
		        			<input type="radio" name="usertype" value="admin" <?php if($userType==admin) echo "checked=checked"?> style="width: 40px"/>Admin
		        		</td>
			        </tr>
			        <tr><td><br/></td></tr>
			        <tr>
		        		<td>
		        			<input type="submit" class="btn btn-info" value="Update " style="margin-left: 120px "/> 
		        		</td>
			        </tr>
			       


	        	</table>
        	</div>	
        </div>
    </center>
      </form>	
</div>

<script src="../controller/updateUser.js">
            
        </script>
          </body>
</html>