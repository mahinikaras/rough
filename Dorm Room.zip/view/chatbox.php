<?php
	session_start();
	if(empty($_SESSION['lastName']))
	{
		header("location:login.html");

	}
	include("header.php");
	$dbservername ="localhost";
	$dbusername ="root";
	$dbpassword ="";
	$dbname ="dormroom";
	$conn = mysqli_connect($dbservername, $dbusername, $dbpassword, $dbname);
	if(!$conn){
			die("Connection Error!".mysqli_connect_error());
	}
							

?>
<head>
		<title>Chatbox</title>
		<link rel="stylesheet" href="dormHome.css"/>
		<link rel="stylesheet" href="chatbox.css"/>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	
</head>
<body>
	
	<div>
		<center>Username:<input type="text" name="search" id="search" style="margin-top: 10px" />
			<input type="button" name="searchbtn" id="searchbtn" value="search" onclick="search()"></center>
	</div>
	<div name="userstatus" id="userstatus" >
		<center><h2>USERS</h2></center>
		<?php 
		$sql="select * from alluser";
		if($result=mysqli_query($conn, $sql)){
		while($row=mysqli_fetch_assoc($result))
				{
				
					$username = $row['userName'];
					
				?>
				<!-- <center><h4><?=$username?></h4></center>	 -->
				<center><input type="button" value="<?=$username?>" onclick="seechats()"></center><br/>
		<?php									
			}

		}else{
				echo "Something Wrong ";
			}
		?>
	</div>
	<div id="users">

	</div>
	<div name="chatbox" id="chatbox" >

	</div>

	<div name="activeusers" id="activeusers" >
		<center><h3>ACTIVE USERS</h3></center>
		<?php 
		$sql="select * from alluser where active='1'";
		if($result=mysqli_query($conn, $sql)){
		while($row=mysqli_fetch_assoc($result))
				{
				
					$username = $row['userName'];
					
				?>
				<center><input type="button" value="<?=$username?>" onclick="seechats()"></center><br/>	
		<?php									
			}

		}else{
				echo "Something Wrong ";
			}
		?>
	</div>
	<input type="text" id="chatText" placeholder="" style="margin-top: 5px;margin-left:359px;width:330px; value="" />
	<input type="button" id="sendBtn" value="send" onclick="send()" style="width:70px">
</body>
<script>
		function search()
		{
			var search=document.getElementById("search").value;
			var xhttp = new XMLHttpRequest();
			  
			xhttp.open("GET", "../controller/chatboxsearch.php?userName="+search, true);
			xhttp.send();
          

			xhttp.onreadystatechange = function() {
			if (this.readyState == 4 && this.status == 200) {
				document.getElementById("users").innerHTML = this.responseText;

				  }
			};
		}
		function send()
		{
			var msg=document.getElementById("chatText").value;

			var userName2=document.getElementById("search").value;
			var xhttp = new XMLHttpRequest();
			  
			xhttp.open("GET", '../controller/chatInsert.php?userName2='+userName2+'&message='+msg, true);
			xhttp.send();
          

			xhttp.onreadystatechange = function() {
			if (this.readyState == 4 && this.status == 200) {
				document.getElementById("chatbox").innerHTML = this.responseText;
				document.getElementById("chatText").value="";

				  }
			};
		}
		function chats()
		{
			
			var userName2=document.getElementById("search").value;
			var xhttp = new XMLHttpRequest();
			  
			xhttp.open("GET", '../controller/chatNameClick.php?userName2='+userName2, true);
			xhttp.send();
          

			xhttp.onreadystatechange = function() {
			if (this.readyState == 4 && this.status == 200) {
				document.getElementById("chatbox").innerHTML = this.responseText;
				document.getElementById("users").innerHTML = "";


				  }
			};
		}
		function intervalchats()
		{
			
			var userName2=document.getElementById("search").value;
			var xhttp = new XMLHttpRequest();
			  
			xhttp.open("GET", '../controller/intervalchats.php?userName2='+userName2, true);
			xhttp.send();
          

			xhttp.onreadystatechange = function() {
			if (this.readyState == 4 && this.status == 200) {
				document.getElementById("chatbox").innerHTML = this.responseText;
				//document.getElementById("users").innerHTML = "";


				  }
			};
		}
		
		function seechats()
		{

			var target=event.target;
			var name=target.value;
			document.getElementById("search").value=name;

			
		}

		// function activeusers()
		// {
		// 	var xhttp = new XMLHttpRequest();  
		// 	xhttp.open("GET", '../controller/activeusers.php', true);
		// 	xhttp.send();
		// 	xhttp.onreadystatechange = function() {
		// 	if (this.readyState == 4 && this.status == 200) {
		// 		document.getElementById("activeusers").innerHTML = '<center><input type="button" value="'+this.responseText+'" onclick="seechats()"></center><br/>';
		// 		//document.getElementById("users").innerHTML = "";


		// 		  }
		// 	};
		// }

		function interval()
		{
			intervalchats();
			//activeusers();
		}

		setInterval(interval,1000);
		
</script>