<?php

session_start();
if(empty($_SESSION['lastName'])  )
{
	header("location:login.html");

}
include("header.php");

?>
<html>
<head>
		<title>HOME</title>
		<link rel="stylesheet" href="dormHome.css"/>
	
</head>


		<div id="content" style="width:72.5% ; height:100%">
				<form>
						<form id="form">
				<input type="text" placeholder="search here"/>
				<input type="submit" value="search"/>
			</form>
			</div>
		</div>
	
	</body>


</html>