<?php
session_start();
if(empty($_SESSION['lastName'])  )
{
	header("location:login.html");

}
include("header.php");

?>
<html>
<head>
		<title>My day</title>
		<link rel="stylesheet" href="dormHome.css"/>
	
</head>
</body>
<form method="post" action="../controller/dayCheck.php" enctype="multipart/form-data">
<div id="content" style="width:72.5% ; height:100% ;">
				
    	<b  style="margin-left: 500px">My day</b>
    
        <center><img width="200"  height="200" style="margin-top: 20px" src="../day/<?=$_SESSION['userName']?>"/>
        <br />
        <input type="file" name="day" style="margin-left: 50px">
        <br/><br/>
        <input type="submit" value="Submit" name="submit" style="margin-top: -10px;margin-right: 150px"></center>
    


		
	
	</body>


</html>