<?php
error_reporting(0);
session_start();
if(empty($_SESSION['lastName']))
{
	header("location:login.html");

}
include("header.php");

?>

<head>
		<title>add notice </title>
		<link rel="stylesheet" href="dormHome.css"/>
	
</head>
<fieldset>
    <legend><b>notice image</b></legend>
    <form method="post" action="../controller/noticepiccheck.php" enctype="multipart/form-data">
        <img width="128" src="../noticepics/<?=$_SESSION['lastName']?>" />
        <br />
        <input type="file" name="propic">
        <hr />
        <input type="submit" value="Submit" name="submit">
    </form>
</fieldset>


