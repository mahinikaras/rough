<?php
error_reporting(0);
session_start();
if(empty($_SESSION['lastName']) )
{
	header("location:login.html");

}
include("header.php");
?>
<head>
		<title>Newspaper</title>
		<link rel="stylesheet" href="dormHome.css"/>
	
</head>
<body>
	<div id="content" style="width:72.5% ; height:100%">
		<div style="margin-top: 10px;margin-left:90px">
			<a href="http://www.prothomalo.com/"  target='_blank'><img src="../newspaper/prothomAlo.jpg" height="200px" width="300px" /></a>
			<a href="https://www.jugantor.com/"  target='_blank'><img src="../newspaper/jugantor.jpg" height="200px" width="300px" /></a>
			<a href="http://www.kalerkantho.com/"  target='_blank'><img src="../newspaper/kalerKontho.jpg" height="200px" width="300px" /></a><br/><br/>
			<a href="https://www.thedailystar.net/"  target='_blank'><img src="../newspaper/dailyStar.png" height="200px" width="300px" /></a>
			<a href="http://www.observerbd.com/"  target='_blank'><img src="../newspaper/dailyObserver.jpg" height="200px" width="300px" /></a>
			<a href="https://www.independent.co.uk/"  target='_blank'><img src="../newspaper/indipendent.jpg" height="200px" width="300px" /></a><br/><br/>
			<a href="https://www.pbs.org/wgbh/frontline/"  target='_blank'><img src="../newspaper/frontline.jpg" height="200px" width="300px" /></a>
			<a href="https://www.forbes.com"  target='_blank'><img src="../newspaper/forbes.jpg" height="200px" width="300px" /></a>
			<a href="https://www.entrepreneur.com/magazine"  target='_blank'><img src="../newspaper/entrepreneur.jpg" height="200px" width="300px" /></a>

		</div>
	</div>
</body>