<?php
session_start();
if(empty($_SESSION['lastName']) )
{
	header("location:login.html");

}
include("header.php");
	$dbservername ="localhost";
	$dbusername ="root";
	$dbpassword ="";
	$dbname ="dormroom";
	$conn = mysqli_connect($dbservername, $dbusername, $dbpassword, $dbname);
	if(!$conn){
			die("Connection Error!".mysqli_connect_error());
	}
?>
	


<html>
	<head>
		<Title>library</title>
	</head>
	<body>
		
		<div class="content" id="content" style="width:72.5% ; height:100%;margin-left:400px;margin-top: -740px">
			<form method="POST" action="../controller/bookUpload.php" enctype="multipart/form-data">
			<center><h1><b>Library</b></h1></center><br/>
			<center><h3 style='margin-top: -20px'>There is no friend as loyal as a book - Ernest Hemingway</h3></center><br/>
			<br/>
			<center><table style="margin-left: 80px">
				<tr>
				<td>Book name</td>
					<td><input type="text" name="bookName"></td>
					<td><input type="file" name="book"></td>
				</tr>
				<td><br/><br/></td>

			</table></center>

			<center><input type="submit" name="submit" id="submit" value="upload" style="margin-top: -30px;margin-right: 10px"></center>
			</form>
			<div style="border:0px solid black;height:200px;display: flex;flex-direction: column;">
				<?php

					$sql='select * from book';
					if($result=mysqli_query($conn,$sql))
					{
						while($row=mysqli_fetch_assoc($result))
						{
							$bookId=$row['id'];
							$bookName=$row['name'];
							$path=$row['path'];
						?>
						 <tr>
							<td><?=$bookId?></td>
							<td>.<?=$bookName?></td>
							<td><a href="../library/<?=$path?>">Download</a></td>
						</tr>
						<td><br/></td>

						<?php
						}
					}


				?>

			</div>
		</div>
	
	</body>
</html>