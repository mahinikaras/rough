<?php
session_start();
if(empty($_SESSION['lastName'])  )
{
	header("location:../login.html");

}
include("header.php");
	
?>
<head>
		<title>change profile picture </title>
		<link rel="stylesheet" href="dormHome.css"/>
	
</head>
<fieldset>
    <legend><b>PROFILE PICTURE</b></legend>
    <form method="post" action="../controller/changepiccheck.php" enctype="multipart/form-data">
        <img width="128" src="../propics/<?=$_SESSION['lastName']?>" />
        <br />
        <input type="file" name="propic">
        <hr />
        <input type="submit" value="Submit" name="submit">
    </form>
</fieldset>