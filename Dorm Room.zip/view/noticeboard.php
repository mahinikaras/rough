<?php
error_reporting(0);
session_start();
if(empty($_SESSION['lastName']))
{
	header("location:login.html");

}
include("header.php");
if($_SESSION['userType']=="admin")
	echo '<head>
		<title>Notice Board</title>
		<link rel="stylesheet" href="dormHome.css"/>
	
</head>
<div>
	<img src="" height=20% width=20% style="margin-left:20% ;margin-top:5%">
	<a href="addnotice.php"><input type="button" value= "add notice" style="margin-left:-12% ;margin-top:-13%"/></a>
	
</div>

<div>
	<h2 style="margin-left:53% ;margin-top:5%">description</h2><br/>
	<p></p>
</div>';

if($_SESSION['userType']=="cr" )
	echo '<head>
		<title>Notice Board</title>
		<link rel="stylesheet" href="dormHome.css"/>
	
</head>
<div>
	<img src="" height=20% width=20% style="margin-left:20% ;margin-top:5%"> 
	<a href="addnotice.php"><input type="button" value= "add notice" style="margin-left:-12% ;margin-top:-13%"/></a>
	
</div>

<div>
	<h2 style="margin-left:53% ;margin-top:5%">description</h2><br/>
	<p></p>
</div>';
?>



