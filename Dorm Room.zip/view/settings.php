<?php
session_start();
if(empty($_SESSION['lastName']) )
{
	header("location:login.html");

}
include("header.php");
echo '<head>
		<title>HOME</title>
		<link rel="stylesheet" href="dormHome.css"/>
	
</head>';
if($_SESSION['userType']=="user")
	echo '<div id="content" style="width:72.5% ; height:100%">
				<ul>
					<li><a href="change_password.php">CHANGE PASSWORD</a></li>
					<li><a href="changepic.php">CHANGE PROFILE PICTURE</a></li>
					
					<li><a href="edit_info.php">EDIT PROFILE INFORMTION</a></li>
					
				</ul>
			</div>';
	else if($_SESSION['userType'] == "cr")
		echo '<div id="content" style="width:72.5% ; height:100%">
				<ul>
					<li><a href="change_password.php">CHANGE PASSWORD</a></li>
					<li><a href="changepic.php">CHANGE PROFILE PICTURE</a></li>
					
					<li><a href="edit_info.php">EDIT PROFILE INFORMTION</a></li>
					
				
				</ul>
			</div>';
		else if($_SESSION['userType'] == "admin")
			echo '<div id="content" style="width:72.5% ; height:100%"	>
				<ul>
					<li><a href="change_password.php">CHANGE PASSWORD</a></li>
					<li><a href="changepic.php">CHANGE PROFILE PICTURE</a></li>
					
					<li><a href="edit_info.php">EDIT PROFILE INFORMTION</a></li>
					<li><a href="moderate.php">Moderate User</a></li>
				</ul>
			</div>';
?>
	
	



