<?php
session_start();
if(empty($_SESSION['lastName']) )
{
	header("location:login.html");

}
include("header.php"); 




?>

<head>
		<title>HOME</title>
		<link rel="stylesheet" href="dormHome.css"/>
	
</head>
	<div id="content" style="width:72.5% ; height:100%">
		<br/>
				<select name="university" id="university" onchange="getSelectedData()"  style="margin-left:25%">
								  <option value="none" ></option>
								  <option value="all">All</option>
								  <option value="Ahsanullah University of Science and Technology" >Ahsanullah University of Science and Technology</option>
								  <option value="American International University-Bangladesh" >American International University-Bangladesh</option>
								  <option value="ASA University Bangladesh" >ASA University Bangladesh</option>
								  <option value="Asian University of Bangladesh" >Asian University of Bangladesh</option>
								  <option value="Atish Dipankar University of Science and Technology" >Atish Dipankar University of Science and Technology</option>
								  <option value="Bangabandhu Sheikh Mujib Medical University" >Bangabandhu Sheikh Mujib Medical University</option>
								  <option value="Bangabandhu Sheikh Mujibur Rahman Agricultural University" >Bangabandhu Sheikh Mujibur Rahman Agricultural University</option>
								  <option value="Bangabandhu Sheikh Mujibur Rahman Maritime University" >Bangabandhu Sheikh Mujibur Rahman Maritime University</option>
								  <option value="Bangabandhu Sheikh Mujibur Rahman Science and Technology University" >Bangabandhu Sheikh Mujibur Rahman Science and Technology University</option>
								  <option value="Bangladesh Agricultural University" >Bangladesh Agricultural University</option>
								  <option value="Bangladesh Islami University" >Bangladesh Islami University</option>
								  <option value="Bangladesh University" >Bangladesh University</option>
								  <option value="Bangladesh University of Business and Technology" >Bangladesh University of Business and Technology</option>
								  <option value="Bangladesh University of Engineering and Technology" > Bangladesh University of Engineering and Technology</option>
								  <option value="Bangladesh University of Professionals" >Bangladesh University of Professionals</option>
								  <option value="Bangladesh University of Textiles" >Bangladesh University of Textiles</option>
								  <option value="Begum Gulchemonara Trust University" >Begum Gulchemonara Trust University</option>
								  <option value="Begum Rokeya University" >Begum Rokeya University</option>
								  <option value="BRAC University" >BRAC University</option>
								  <option value="Chittagong University of Engineering and Technology" >Chittagong University of Engineering and Technology</option>
								  <option value="Chittagong Veterinary and Animal Sciences University" >Chittagong Veterinary and Animal Sciences University</option>
								  <option value="City University" >City University</option>
								  <option value="Comilla University" >Comilla University</option>
								  <option value="Coxs Bazar International University" >Coxs Bazar International University</option>
								  <option value="Daffodil International University" >Daffodil International University</option>
								  <option value="Darul Ihsan University" >Darul Ihsan University</option>
								  <option value="Dhaka International University" >Dhaka International University</option>
								  <option value="Dhaka University of Engineering and Technology" >Dhaka University of Engineering and Technology</option>
								  <option value="East Delta University" >East Delta University</option>
								  <option value="East West University" >East West University</option>
								  <option value="Eastern University, Bangladesh" >Eastern University, Bangladesh</option>
								  <option value="European University of Bangladesh" >European University of Bangladesh</option>
								  <option value="Gono Bishwabidyalay" >Gono Bishwabidyalay</option>
								  <option value="Green University of Bangladesh" >Green University of Bangladesh</option>
								  <option value="Hajee Mohammad Danesh Science and Technology University" >Hajee Mohammad Danesh Science and Technology University</option>
								  <option value="IBAIS University" >IBAIS University</option>
								  <option value="Independent University, Bangladesh" >Independent University, Bangladesh</option>
								  <option value="International Islamic University, Chittagong" >International Islamic University, Chittagong</option>
								  <option value="International University of Business Agriculture and Technology" >International University of Business Agriculture and Technology</option>
								  <option value="Islamic University" >Islamic University</option>
								  <option value="Islamic University of Technology" >Islamic University of Technology</option>
								  <option value="Jagannath University" >Jagannath University</option>
								  <option value="Jahangirnagar University" >Jahangirnagar University</option>
								  <option value="Jatiya Kabi Kazi Nazrul Islam University" >Jatiya Kabi Kazi Nazrul Islam University</option>
								  <option value="Jessore University of Science and Technology" >Jessore University of Science and Technology</option>
								  <option value="Khulna University" >Khulna University</option>
								  <option value="Khulna University of Engineering and Technology" >Khulna University of Engineering and Technology</option>
								  <option value="Khwaja Yunus Ali University" >Khwaja Yunus Ali University</option>
								  <option value="Leading University" >Leading University</option>
								  <option value="Manarat International University" >Manarat International University</option>
								  <option value="Mawlana Bhashani Science and Technology University" >Mawlana Bhashani Science and Technology University</option>
								  <option value="Metropolitan University" >Metropolitan University</option>
								  <option value="National University, Bangladesh" >National University, Bangladesh</option>
								  <option value="Noakhali Science and Technology University" >Noakhali Science and Technology University</option>
								  <option value="North South University" >North South University</option>
								  <option value="North Western University" >North Western University</option>
								  <option value="Northern University of Bangladesh" >Northern University of Bangladesh</option>
								  <option value="Notre Dame University Bangladesh" >Notre Dame University Bangladesh</option>
								  <option value="Pabna Science and Technology University" >Pabna Science and Technology University</option>
								  <option value="Patuakhali Science and Technology University" >Patuakhali Science and Technology University</option>
								  <option value="Port City International University">Port City International University</option>
								  <option value="Premier University" >Premier University</option>
								  <option value="Presidency University, Bangladesh" >Presidency University, Bangladesh</option>
								  <option value="Prime University" >Prime University</option>
								  <option value="Primeasia University" >Primeasia University</option>
								  <option value="Rajshahi University" >Rajshahi University</option>
								  <option value="Rajshahi University of Engineering and Technology" >Rajshahi University of Engineering and Technology</option>
								  <option value="Rangamati University of Science and Technology" >Rangamati University of Science and Technology</option>
								  <option value="Royal University of Dhaka" >Royal University of Dhaka</option>
								  <option value="Shahjalal University of Science and Technology" >Shahjalal University of Science and Technology</option>
								  <option value="Shanto Mariam University of Creative Technology" >Shanto Mariam University of Creative Technology</option>
								  <option value="Sher-e-Bangla Agricultural University" >Sher-e-Bangla Agricultural University</option>
								  <option value="Sonargaon University" >Sonargaon University</option>
								  <option value="Southeast University, Bangladesh" name="University">Southeast University, Bangladesh</option>
								  <option value="Southern University Bangladesh" >Southern University Bangladesh</option>
								  <option value="Stamford University Bangladesh" >Stamford University Bangladesh</option>
								  <option value="State University of Bangladesh" >State University of Bangladesh</option>
								  <option value="Sylhet Agricultural University" >Sylhet Agricultural University</option>
								  <option value="Sylhet International University" >Sylhet International University</option>
								  <option value="The Millenium University" >The Millenium University</option>
								  <option value="The People's University of Bangladesh">The People's University of Bangladesh</option>
								  <option value="The University of Asia Pacific" >The University of Asia Pacific</option>
								  <option value="United International University" >United International University</option>
								  <option value="University of Barisal" >University of Barisal</option>
								  <option value="University of Chittagong" >University of Chittagong</option>
								  <option value="University of Development Alternative" >University of Development Alternative</option>
								  <option value="University of Dhaka" >University of Dhaka</option>
								  <option value="University of Information Technology and Sciences" >University of Information Technology and Sciences</option>
								  <option value="University of Liberal Arts Bangladesh" >University of Liberal Arts Bangladesh</option>
								  <option value="University of Science and Technology Chittagong" >University of Science and Technology Chittagong</option>
								   <option value="University of South Asia, Bangladesh" >University of South Asia, Bangladesh</option>
								  <option value="Uttara University" >Uttara University</option>
								  <option value="Victoria University of Bangladesh" >Victoria University of Bangladesh</option>
								  <option value="World University of Bangladesh" >World University of Bangladesh</option>
				</select>

				<div id="users"><?php


                     
                     $conn = mysqli_connect('localhost', 'root', '', 'dormroom');
                     $sql = "select * from alluser";
                     $result = mysqli_query($conn, $sql);

					while ($row = mysqli_fetch_assoc($result)) 
					{
						echo '<br/>';
						echo " $row[id] ~First Name : $row[firstName] ~ Last Name : $row[lastName] ~ User Name : $row[userName] ~Email : $row[emailId] ~ DOB : $row[dob] ~Uni Id : $row[universityId] ~ User Type : $row[userType] <a href='../controller/deleteUserController.php?id=$row[id]'>Delete</a>	<br/>";
					}


						?>
					
				</div>
			</div>
			
			<script>

				function getSelectedData(){
				

				var university = document.getElementById('university').value;

				var xhttp = new XMLHttpRequest();
			  
				xhttp.open("GET", "../controller/fetchuserDelete.php?university="+university, true);
				xhttp.send();
          

					xhttp.onreadystatechange = function() {
					    if (this.readyState == 4 && this.status == 200) {
					     document.getElementById("users").innerHTML = this.responseText;

					    }
					};
				}
			</script>	

