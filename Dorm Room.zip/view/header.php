<?php
error_reporting(0);
session_start();
if(empty($_SESSION['lastName']) )
{
	header("location:login.html");

}
?>

<html>
	<head>
		
		<link rel="stylesheet" href="dormHome.css"/>
		
	
	</head>
	<body>
		<div id="head" align="right" style="width:100%;   background-image: linear-gradient(to bottom, #b4b2cb, #9391a6, #747283, #555461, #393841);" >
			<!-- <a href="help.php" >help</a> -->
			<a href="settings.php">settings</a>
			
			<a href="home.php">home</a>
			<a href="../controller/logout.php">logout</a>
			
			
			<form id="form"  style="margin-top:-10px;" >
				<input type="text" id="searchName" placeholder="search here" onkeyup="search()" />
				<input type="button"  value="search" onclick ="search()" />
				<div id="userSuggestion" style="border:1px solid black;width:160px;height:200px;margin-top: 5px;position:fixed;background-color: gray;display:none"></div>
			</form>
			<div id="logo">
				<img src="logo.jpg" width="50px" height="40px" align="left">
			</div>
			<div id="id">
				
				<div id="image">
					<?php
					  $con=mysqli_connect("localhost","root","","dormroom");
                       $username = $_SESSION['userName'];
                        $sql = "select * from images where userName='$username'and photoType='propic' order by id desc" ;
                       $query = mysqli_query($con, $sql);
                       $num = mysqli_num_rows($query);
                       for($i=0; $i<1; $i++){
                           $result = mysqli_fetch_array($query);
                           $img = $result['image'];
                           echo '<a href="userpersonalprofile.php"><img src="data:image;base64,'.$img.'" width="40px" height="40px"/> </a>';
                       }
					  ?>
					
				</div>
				<div id="name">
					<?php echo $_SESSION['userName']?>
				</div>
				
			</div>
			
		</div>
		<div id="body"  style="width:100%; height:100%;  background-color:white;" >
			<div id="left" style="height:100%;   background-image: linear-gradient(to right bottom, #b4b2cb, #9391a6, #747283, #555461, #393841);">
				<div style="background-color:; margin:30px">
				<ul>
					<li><a href="campus.php">campus</a></li>
					<!-- <li><a href="noticeboard.php">notice board</a></li> -->
					<li><a href="library.php">library</a></li>
					<li><a href="newspaper.php">newspaper</a></li>
					<li><a href="chatbox.php">Chatbox</a></li>
					<li><a href="day.php">My day</a></li>
					<li><a href="userpersonalprofile.php">Profile</a></li>
					<li><a href="idcard.php">ID card</a></li>
				</ul><br/>
			</div>
			<div style="">
				<center>
					<?php
					  $con=mysqli_connect("localhost","root","","dormroom");
                       $username = $_SESSION['userName'];
                        $sql = "select * from images where userName='$username'and photoType='myday' order by id desc" ;
                       $query = mysqli_query($con, $sql);
                       $num = mysqli_num_rows($query);
                       for($i=0; $i<1; $i++){
                           $result = mysqli_fetch_array($query);
                           $img = $result['image'];
                           echo '<img src="data:image;base64,'.$img.'" width="140px" height="200px" style="margin-top: 50px;margin-right: 26px" alt="upload your day"/> </a>';
                       }
					  ?>
					<!-- <img src="../day/<?=$_SESSION['userName']?>" height=200px width=140px style="margin-top: 50px;margin-right: 26px" alt="upload your day"> -->
					<h4 style="margin-top:10px;margin-right: 25px">My Day</h4>
					
				</center>



				</div>
				<!-- <img src="dormRoom.png" width="150px" style="margin-left: 110px;margin-top:300px" /	> -->
			</div>
			<script>
				function search()
				{
					var searchName=document.getElementById("searchName").value;
					//alert(searchName);
					var xhttp = new XMLHttpRequest();
					//alert(searchName);
					if(searchName==="")
					{
						document.getElementById("userSuggestion").style.display = "none";
					}
					else{
						document.getElementById("userSuggestion").style.display = "block"; 
					}
					
					xhttp.open("GET", '../controller/headerSearchName.php?searchName='+searchName, true);
					xhttp.send();
		          

					xhttp.onreadystatechange = function() {
					if (this.readyState == 4 && this.status == 200) {
						document.getElementById("userSuggestion").innerHTML = this.responseText;
						//document.getElementById("users").innerHTML = "";


						  }
					};
				}
			</script>