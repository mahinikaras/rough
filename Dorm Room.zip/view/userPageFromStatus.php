<?php
	session_start();
	if(empty($_SESSION['lastName']))
	{
		header("location:login.html");

	}
	include("header3.php");
	$userName=$_GET['userName'];
	$dbservername ="localhost";
	$dbusername ="root";
	$dbpassword ="";
	$dbname ="dormroom";
	$conn = mysqli_connect($dbservername, $dbusername, $dbpassword, $dbname);
	if(!$conn){
			die("Connection Error!".mysqli_connect_error());
	}
							

?>

<html>
	<head>
		<title>HOME</title>
		<link rel="stylesheet" href="dormHome.css"/>
		<style >
			.element::-webkit-scrollbar { width: 0 !important }
			.content::-webkit-scrollbar { width: 0 !important }
		</style>
	
	</head>
	<body>
			<div class="content" id="content" style="width:72.5% ; height:100%;">
				
				<!-- <form method="post" action="../controller/statusFromHome.php" onsubmit="return post()">
					<center>
					<input type="text" name="post" id="status" value="" placeholder="write something helpful" style="width:400px;height:80px;margin-top: 20px;" /><br/>
					<input type="submit" name="submit" value="post" style="margin-top: 10px;"  />

					
				    </center>
				</form> -->
				    <center><div id="feed" style="border: 0px solid black;height: 200px;width: 700px;margin-top: 20px;">
							<?php

							
								$sql = "select * from status where userName='$userName' order by id desc" ;
								if($result=mysqli_query($conn, $sql)){
								while($row=mysqli_fetch_assoc($result))
								{
									$image = $row['image'];
									$username = $row['userName'];
									$post = $row['post'];
									$id=$row['id'];
									$vote=$row['Vote'];
									$dislike=$row['dislike'];
									$id2=$id-10000;

									?>
									
									<div id="" style=	"border: 0px solid black;display: flex;flex-direction: column;margin-top: 20px; background-color:#eff1f4 ">

										<?php
											  $con=mysqli_connect("localhost","root","","dormroom");
						            
						                        $sql3 = "select * from images where userName='$username'and photoType='propic' order by id desc" ;
						                       $query = mysqli_query($con, $sql3);
						                       $num = mysqli_num_rows($query);
						                       for($i=0; $i<1; $i++){
						                           $result3 = mysqli_fetch_array($query);
						                           $img = $result3['image'];
						                           echo '<img src="data:image;base64,'.$img.'" height=30% width=8% style="margin-left:-87%;margin-top: 10px"/> ';
						                       }
											  ?>
								    		<!-- <img src="<?=$image?> " height=30% width=8% style="margin-left:-87%;margin-top: 10px" /> -->
								    		<h3 style="float: left;margin-top: 10px;margin-left: -87%" ><a href="userPageFromStatus.php?userName=<?=$username?>"><?=$username?></a></h3><br/><br/><br/>
					                        <div style="border: 0px solid black;width:500px;margin-right: 180px;margin-top:-85" ><h4 style="color: rgb(47, 142, 142);word-break: break-word;float: left;" ><?=$post?></h4></div>
					                        <input type="button" name="like" id="<?=$id?>" value="Like <?=$vote?>" style="width:10%;margin-right: 610;margin-bottom: 10px" onclick="voteCounter()">
					                        <input type="button" name="dislike" id="<?=$id2?>" value="Dislike <?=$dislike?>" style="width:10%;margin-right: 455;margin-bottom: 10px;margin-top:-32" onclick="dislike()">
					                         <div class="element" id="commentView<?=$id?>" style="border:1px solid black;background:white;height:180;width:250;margin-top: -170;margin-left:430;overflow: scroll;line-height:90%;vertical-align: left" >
					                        	<?php
											$sql2="select * from comment where statusId='$id'";
											$result2=mysqli_query($conn, $sql2);
											while($row=mysqli_fetch_assoc($result2))
											{
												$comment=$row['comment'];
					                        ?>
					                        	<?=$comment?></br>

					                        <?php
											}
					                        ?>	
					                        </div>
					                         <input type="text" name="comment" id="comment<?=$id?>" style="width:165;margin-top: 10px;margin-left: 340">
					                        <input type="button" id="<?=$id?>" value="comment" style="width:10%;margin-left: 600;margin-top: -22px;margin-bottom: 10px" onclick="comment()">

					                    </div>


								<?php }
           
           
		
	 
								}else{
									echo "<br/> Something Wrong".mysqli_error($conn);
								}
								?>
				    	
		   			</div></center>
				
				
			</div>
			
	
	</body>
</html>
	<script>
		
           function post()
           {

                  var post = document.getElementById("status").value;
                  if(post=="")
                  {
                       return false;
                  }
                  else return true;
                 
           }
           function voteCounter()
           {	
           		
           			var target = event.target;
				var id = target.id;
           		//alert(id);
           	 	var xhttp = new XMLHttpRequest();
			  
				xhttp.open("GET", "../controller/voteCount.php?id="+id, true);
				xhttp.send();
          

					xhttp.onreadystatechange = function() {
					    if (this.readyState == 4 && this.status == 200) {
					     document.getElementById(id).value = "Like "+this.responseText;

					    }
					};
           		
           		
           }

            function dislike()
           {	
           		
           		var target = event.target;
				var id = target.id;
           		//alert(id);
           	 	var xhttp = new XMLHttpRequest();
			  
				xhttp.open("GET", "../controller/dislikeCount.php?id="+id, true);
				xhttp.send();
          

					xhttp.onreadystatechange = function() {
					    if (this.readyState == 4 && this.status == 200) {
					     document.getElementById(id).value = "Dislike "+this.responseText;

					    }
					};
           		
           		
           }
           function comment()
           {	
           		
           		var target = event.target;
				var id = target.id;
				var comment=document.getElementById("comment"+id).value;
           		//alert(id);
           	 	var xhttp = new XMLHttpRequest();
           	 	//alert(id);
			  
				xhttp.open("GET", "../controller/comment.php?id="+id+"&comment="+comment, true);
				xhttp.send();
          

					xhttp.onreadystatechange = function() {
					    if (this.readyState == 4 && this.status == 200) {
					     document.getElementById("commentView"+id).innerHTML = this.responseText;
					     document.getElementById("comment"+id).value=null;


					    }
					};
           		//location.reload();
           		
           }

	</script>