<?php
error_reporting(0);
session_start();
if(empty($_SESSION['lastName']))
{
	header("location:login.html");

}
include("header.php");
if($_SESSION['userType']=="admin" || $_SESSION['userType']=="cr" )
	echo '<head>
		<title>Add dfescription</title>
		<link rel="stylesheet" href="dormHome.css"/>
	
</head>
<div>
	<h2 style="margin-left:53% ;margin-top:5%">description</h2><br/>
	<p></p>
</div>
<div style="margin-left:40% ;margin-top:-2%">
	<form method="post" action="">
<p><textarea name="moreinfo" cols="60" rows="10" required="required">
</textarea><br/>
<input type="submit" value="Submit"> <input type="reset"></p>
</form>
	
</div>

';

?>



