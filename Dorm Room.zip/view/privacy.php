<?php
session_start();
if(empty($_SESSION['lastName']) )
{
	header("location:login.html");

}
?>
		
			<div id="content">
				<form>
					<h1>options of changing the default privacy settings would be here.
					
					such as the profile content would be public or not etc</h1><br/>
					
				</form>
				
			</div>
		</div>
