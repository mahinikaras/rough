<?php
session_start();
if(empty($_SESSION['lastName']) )
{
	header("location:login.html");

}
include("header.php");

?>
<html>
<head>
		<title>Campus</title>
		<link rel="stylesheet" href="dormHome.css"/>
	
</head>


</body>
			<div id="content" style="width:72.5% ; height:100%">
				<center><h3> get the informations  about your and other's campus.</h3></center>
			<div>
				<center><h4 style="margin-left:0px">university:
				<select style="width:95px" id="varsity" onchange="show()">
					<option value="none"></option>
					<option value="DU">DU</option>
					<option value="AIUB">AIUB</option>
					<option value="NSU">NSU</option>

				</select>
				</h4>
				<!-- <h4 style="margin-left:250px;margin-top:-40px">about: -->
				<!-- <select id="about" onchange="show()">
					<option value="none"></option>
					<option value="information">information</option>
					<option value="faculties">faculties</option>
					<option value="students">students</option>
				</select>
				</h4> -->
			</center>
			</div>
					<div id="varsityImage" style="border:0px solid black;height:197px ;width:380px;margin-left: 360px;margin-top: 70px">
						
					</div>
				<div name="info" id="info" >
						<div style="margin-top: -250px;margin-left:90px">
			<img src="../campus/image/aiub8.jpg" height="200px" width="300px" />
			<img src="../campus/image/aiub7.jpg" height="200px" width="300px" />
			<img src="../campus/image/aiub6.jpg" height="200px" width="300px" /><br/><br/>
			<img src="../campus/image/aiub5.jpg" height="200px" width="300px" />
			<img src="../campus/image/aiub4.jpg" height="200px" width="300px" />
			<img src="../campus/image/aiub3.jpg" height="200px" width="300px" /><br/><br/>
			<img src="../campus/image/aiub2.jpg" height="200px" width="300px" />
			<img src="../campus/image/aiub1.jpg" height="200px" width="300px" />
			<img src="../campus/image/aiub9.jpg" height="200px" width="300px" />
			

		</div>
					
				</div>
			</div>

		
		</body>
	</html>
	<script >
		function show()
		{
           //alert("varsity");
			var varsity =  document.getElementById('varsity').value;
			//var about = document.getElementById("about").value;
			//alert(about);
			
			if(varsity==="none" )
			{
				var div='<div style="margin-top: -50px;margin-left:90px"><img src="../campus/image/aiub9.jpg" height="200px" width="300px" style="margin-top: 0px;margin-left:-400px"/><img src="../campus/image/aiub8.jpg" height="200px" width="300px" style="margin-top: -200px;margin-left:10px" /><img src="../campus/image/aiub7.jpg" height="200px" width="300px"  style="margin-top: -200px;margin-left:220px" /><br/><br/><img src="../campus/image/aiub6.jpg" height="200px" width="300px"  style="margin-top: -0px;margin-left:-400px" /><img src="../campus/image/aiub5.jpg" height="200px" width="300px" style="margin-top: -0px;margin-left:10px"  /><img src="../campus/image/aiub4.jpg" height="200px" width="300px" style="margin-top: -200px;margin-left:220px"  /><img src="../campus/image/aiub3.jpg" height="200px" width="300px" style="margin-top: 10px;margin-left:-400px" /><img src="../campus/image/aiub2.jpg" height="200px" width="300px" style="margin-top: -0px;margin-left:10px" /><img src="../campus/image/aiub1.jpg" height="200px" width="300px" style="margin-top: -200px;margin-left:220px" /></div>'
				document.getElementById("varsityImage").innerHTML =div;
				document.getElementById("info").innerHTML ="";
 				
			}
			else if(varsity==="AIUB" )
			{
 				document.getElementById("varsityImage").innerHTML ="<img src='../campus/image/aiub7.jpg' style='max-height:100%;max-width:100%'>";
 				document.getElementById("info").innerHTML ="<p style='color:#191e66'><b>American International University - Bangladesh (AIUB) is a government approved private university founded in 1994 by Dr. Anwarul Abedin. The university is an independent organization with its own Board of Trustees. <b>Vision :</b> AMERICAN INTERNATIONAL UNIVERSITY BANGLADESH (AIUB) envisions promoting professionals and excellent leadership catering to the technological progress and development needs of the country.MissionAMERICAN INTERNATIONAL UNIVERSITY-BANGLADESH (AIUB) is committed to provide quality and excellent computer-based academic programs responsive to the emerging challenges of the time. It is dedicated to nurture and produce competent world class professional imbued with strong sense of ethical values ready to face the competitive world of arts, business, science, social science and technology.<br/><center> For more information visit official website of <a href='http://www.aiub.edu' target='_blank'>AIUB</a></center></b></p>";
			}
			else if(varsity==="NSU")
			{
 				document.getElementById("varsityImage").innerHTML ="<img src='../campus/image/NSU.jpg' style='max-height:100%;max-width:100%'>";
 				document.getElementById("info").innerHTML ="<p style='color:#191e66'><b>North South University (NSU), the first private university in Bangladesh, was established in 1992 by the then Foundation for Promotion of Education and Research (FPER) - a charitable, non-profit, non-commercial and non-political organization. The FPER later was renamed as the NSU Foundation and is presently called the North South Foundation. The Foundation is comprised of a group of eminent industrialists, prominent patrons of education, notable philanthropists, widely experienced academics and senior civil servants of the country. In the early 1990s, they had a dream to set up a world-class university as a center of excellence in higher education in the private sector. Their dedication, tireless efforts, and hard work paved the way for approval of the establishment of NSU.<br/> <center>For more information visit official website of <a href='http://www.northsouth.edu'  target='_blank'>NSU	</a></center></b></p>";
			}
			else if(varsity==="DU")
			{
 				document.getElementById("varsityImage").innerHTML ="<img src='../campus/image/DU3.jpg' style='max-height:100%;max-width:100%'>";
 				document.getElementById("info").innerHTML ="<p style='color:#191e66'><b>On the first day of July 1921 the University of Dhaka opened its doors to students with Sir P.J. Hartog as the first Vice-Chancellor of the University. The University was set up in a picturesque part of the city known as Ramna on 600 acres of landThe University started its activities with 3 Faculties,12 Departments, 60 teachers, 877 students and 3 dormitories (Halls of Residence) for the students. At present the University consists of 13 Faculties, 83 Departments, 12 Institutes, 20 residential halls, 3 hostels and more than 56 Research Centres. The number of students and teachers has risen to about 37018 and 1992 respectively.<br/> <center>For more information visit official website of <a href='http://www.du.ac.bd'  target='_blank'>DU	</a></center></b></p>";
			}
		}
	</script>



	