<?php

session_start();
if(empty($_SESSION['lastName']))
{
	header("location:login.html");

}


$comment1 = $_GET['comment'];
$id = $_GET['id'];
$userName= $_SESSION['userName'];

$comment2 = $userName." : ".$comment1;
//echo $comment2;





if(!empty($comment1))
{
	$dbservername ="localhost";
	$dbusername ="root";
	$dbpassword ="";
	$dbname ="dormroom";
	$conn = mysqli_connect($dbservername, $dbusername, $dbpassword, $dbname);
	if(!$conn){
		die("Connection Error!".mysqli_connect_error());
	}
	
	$sql = "insert into comment values('','$id','$comment2')";
	
	if(mysqli_query($conn, $sql)){
		
			

		     $sql2="select * from comment where statusId='$id'";
			$result2=mysqli_query($conn, $sql2);
			while($row=mysqli_fetch_assoc($result2))
			{
				$comment=$row['comment'];
			
				echo $comment."</br>";
			}

	
	 
	}else{
		echo "<br/> Something Wrong".mysqli_error($conn);
	}

	mysqli_close($conn);
}
else 
	// header("location:../view/home.php");
	//echo "error";
		

?>