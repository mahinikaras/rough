<?php

error_reporting(0);


$firstName = $_POST['firstname'];
$lastName=$_POST['lastname'];
$userName=$_POST['username'];
$emailId=$_POST['emailid'];
$password=$_POST['password'];
$dob=$_POST['dob'];
$university=$_POST['University'];
$universityId=$_POST['uniid'];
$department=$_POST['department'];
$gender=$_POST['gender'];
$userType=$_POST['usertype'];





//db connection

	$dbservername ="localhost";
	$dbusername ="root";
	$dbpassword ="";
	$dbname ="dormroom";

	if(empty($firstName) ||empty($lastName) ||empty($userName) ||empty($emailId) ||empty($password) ||empty($dob) ||empty($university) ||empty($universityId) 
||empty($department)||empty($gender)||empty($userType))
				{die("Please fill up all the fields\r\n");}
	$conn = mysqli_connect($dbservername, $dbusername, $dbpassword, $dbname);
	
	if(!$conn){
		die("Connection Error!".mysqli_connect_error());
	}
	
	$sql = "insert into alluser values('','$firstName','$lastName','$userName','$emailId','$password','$dob','$university','$universityId','$department','$gender','$userType','0')";
	
	if(mysqli_query($conn, $sql)){
		echo "<br/> Registration completed! <br/>		
		<a href=../view/login.html>Log In</a>";
	}else{
		echo "<br/> Something Wrong".mysqli_error($conn);
	}

	mysqli_close($conn);

?>