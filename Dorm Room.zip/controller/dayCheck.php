
<?php
						session_start();
						if(empty($_SESSION['userName']))
						{
							header("location:../view/login.php");
						}
                        if(isset($_POST['submit'])){
                            if(getimagesize($_FILES['day']['tmp_name'])==false){
                                echo "failed";
                            }
                            else{
                                $name=addslashes($_FILES['day']['name']);
                                $image=base64_encode(file_get_contents(addslashes($_FILES['day']['tmp_name'])));
                                saveimage($name, $image);
                            }
                        }
                  // display();
                    function saveimage($name, $image){
                        $con=mysqli_connect("localhost","root","","dormroom");
                        $username = $_SESSION['userName'];
                        $sql="insert into images values('','$image','$name','$username','myday')";
                        $query=mysqli_query($con,$sql);
                        if($query){
                            header("location:../view/userpersonalprofile.php");
                        }
                        else{
                            echo"not uploaded";
                        }
                    }
                   // function display(){
                   //      $con=mysqli_connect("localhost","root","","community");
                   //     $username = $_SESSION['username'];
                   //      $sql = "select * from images where UserName='$username'" ;
                   //     $query = mysqli_query($con, $sql);
                   //     $num = mysqli_num_rows($query);
                   //     for($i=0; $i<$num; $i++){
                   //         $result = mysqli_fetch_array($query);
                   //         $img = $result['image'];
                   //         echo '<img src="data:image;base64,'.$img.'" width="150px" height="150px" style="margin:5px">';
                   //     }
                   // }

                    ?>