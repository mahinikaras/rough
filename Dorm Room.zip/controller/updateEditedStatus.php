<?php
	session_start();
	if(empty($_SESSION['lastName']))
	{
		header("location:login.html");

	}
	
	$id=$_GET['id'];
	$post=$_GET['post'];
	//echo $id;
	$dbservername ="localhost";
	$dbusername ="root";
	$dbpassword ="";
	$dbname ="dormroom";
	$conn = mysqli_connect($dbservername, $dbusername, $dbpassword, $dbname);
	if(!$conn){
			die("Connection Error!".mysqli_connect_error());
	}
	

						$sql = "update status set  post='$post' where id='$id'" ;
						//echo $sql;
								if($result=mysqli_query($conn, $sql)){
										echo "done";
								}
							
								else echo "Something Wrong";
									

?>
