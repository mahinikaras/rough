<?php

	session_start();
	if(empty($_SESSION['lastName']) )
	{
		header("location:login.html");

	}


					$id=$_GET['id'];
					$conn = mysqli_connect('localhost', 'root', '', 'dormroom');
                     $sql = "delete from alluser where id='$id'";
                     $result = mysqli_query($conn, $sql);
                     if($result)
                     {
                     	header("location:../view/deleteUser.php?status=success");
                     }else{
                     	echo "Something Wrong";
                     }
?>