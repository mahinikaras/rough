<?php

	session_start();
	if(empty($_SESSION['lastName']) )
	{
		header("location:login.html");

	}

$id=$_GET['id'];
$firstName = $_POST['firstname'];
$lastName=$_POST['lastname'];
$userName=$_POST['username'];
$emailId=$_POST['emailid'];
$password=$_POST['password'];
$dob=$_POST['dob'];
$university=$_POST['University'];
$universityId=$_POST['uniid'];
$department=$_POST['department'];
$gender=$_POST['gender'];
$userType=$_POST['usertype'];





//db connection

	$dbservername ="localhost";
	$dbusername ="root";
	$dbpassword ="";
	$dbname ="dormroom";

	if(empty($firstName) ||empty($lastName) ||empty($userName) ||empty($emailId) ||empty($password) ||empty($dob) ||empty($university) ||empty($universityId) 
||empty($department)||empty($gender)||empty($userType))
				{die("Please fill up all the fields\r\n");}
	$conn = mysqli_connect($dbservername, $dbusername, $dbpassword, $dbname);
	
	if(!$conn){
		die("Connection Error!".mysqli_connect_error());
	}
	
	$sql = "update alluser set firstName='$firstName',lastName='$lastName',userName='$userName',emailId='$emailId',password='$password',dob='$dob',university='$university',universityId='$universityId',department='$department',gender='$gender',userType='$userType' WHERE id='$id'";

	
	
	if(mysqli_query($conn, $sql)){

		$_SESSION['firstName']=$firstName;
		$_SESSION['lastName']=$lastName;
		$_SESSION['userName']=$userName;
		$_SESSION['emailId']=$emailId;
		$_SESSION['password']=$password;
		$_SESSION['dob']=$dob;
		$_SESSION['university']=$university;
		$_SESSION['universityId']=$universityId;
		$_SESSION['department']=$department;
		$_SESSION['gender']=$gender;
		$_SESSION['userType']=$userType;

		echo "<br/> Updated User Information! <br/>	

		<a href=../view/updateUser.php>View User</a>";
		
	}else{
		echo "<br/> Something Wrong".mysqli_error($conn);
	}

	mysqli_close($conn);

?>