<?php

		session_start();
		if(empty($_SESSION['lastName']))
		{
			header("location:login.html");

		}

		$searchName=$_GET['searchName'];
		//db connection
		if(!empty($searchName))
		{
			$dbservername ="localhost";
			$dbusername ="root";
			$dbpassword ="";
			$dbname ="dormroom";
			$conn = mysqli_connect($dbservername, $dbusername, $dbpassword, $dbname);
			if(!$conn){
				die("Connection Error!".mysqli_connect_error());
			}

			$sql="select * from alluser where userName like '$searchName%'";
			//echo $sql;
			if($result=mysqli_query($conn, $sql))
			{
				while($row=mysqli_fetch_assoc($result))
				{
					echo "<a href='userPageFromStatus.php?userName=$row[userName]'><center><input type='button' id='$row[userName]' value='$row[userName]' style='margin-top:10px'/></center></a><br/>";
				}
			}
		}

	
?>