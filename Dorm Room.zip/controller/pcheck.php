<?php
error_reporting(0);
session_start();
session_start();
if(empty($_SESSION['lastName']) )
{
	header("location:../view/login.html");

}
$cpass = $_POST['cpass'];
$npass = $_POST['npass'];
$rpass = $_POST['rpass'];
$id=$_SESSION['universityId'];




  $server="localhost";
  $username="root";
  $password="";
  $db="dormroom";
  
  $mycon = mysqli_connect($server,$username,$password,$db);
  $sql = "select * from allUser where universityId='$id'";
  
  $result=mysqli_query($mycon,$sql);
  $row=mysqli_fetch_assoc($result);
  $rown=mysqli_num_rows($result);
  
  if( $rown == 1)
  {  
	  $p = $row['password'];
		

  }
  
  
 

if(!empty($_POST['cpass']) && !empty($_POST['rpass']) && !empty($_POST['npass']) )
{
   if(strlen($npass) >= 8)
	{
		if($cpass == $_SESSION["password"]) 
		{
			if($npass == $rpass )
			{
				 $sql2 = "update allUser set password='$npass' where universityId='$id'";
	             if($result=mysqli_query($mycon,$sql2))
				 {
					       $_SESSION["password"]=$npass;
		                   echo ("password changed successfully");
	                       echo '<a href="../view/home.php">Home</a>'	;				   
				 }					   
			}
			else
				echo ("new pass and retype pass should be same");
		}
		else
			echo ("current password doesn't match");
	}
	else
		echo "password requires at least 8 character";
}
else
	echo "fill up the full form";


?>