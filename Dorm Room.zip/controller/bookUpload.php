<?php
						session_start();
						if(empty($_SESSION['userName']))
						{
							header("location:../view/login.php");
						}
									$dbservername ="localhost";
									$dbusername ="root";
									$dbpassword ="";
									$dbname ="dormroom";
									$conn = mysqli_connect($dbservername, $dbusername, $dbpassword, $dbname);
									if(!$conn){
											die("Connection Error!".mysqli_connect_error());
						}

						if(isset($_POST['submit']))
						{
							$bookName=$_POST['bookName'];
							$book=$_FILES['book']['name'];
							$tmp_name=$_FILES['book']['tmp_name'];

							if($bookName && $book)
							{
								$location="../library/".$bookName;
								$book1=explode(".", $book);
								$ext=$book1[1];
								$allowed=array("pdf","doc");
								if(in_array($ext, $allowed))
									{
									move_uploaded_file($tmp_name, $location);
									$sql="insert into book values('','$bookName','$location')";
									if(mysqli_query($conn,$sql))
									{
										header("location:../view/library.php");
									}
									else
									{
										echo "something Wrong";
									}
								}
								else
								{
									echo "upload only pdf and doc ";
								}
							}
							else
							{
								echo "Please select a pdf or doc document Or check the book name";
							}
						}
?>						

