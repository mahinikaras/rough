<?php

session_start();
if(empty($_SESSION['lastName']))
{
	header("location:login.html");

}


$status = $_POST['post'];
$lastname = $_SESSION['lastName'];
$userName= $_SESSION['userName'];


//db connection
if(!empty($status))
{
	$dbservername ="localhost";
	$dbusername ="root";
	$dbpassword ="";
	$dbname ="dormroom";
	$conn = mysqli_connect($dbservername, $dbusername, $dbpassword, $dbname);
	if(!$conn){
		die("Connection Error!".mysqli_connect_error());
	}
	
	$sql = "insert into status values('','../propics/$userName','$userName','$status','0','0')";
	
	if(mysqli_query($conn, $sql)){
		
			

		     header("location:../view/home.php");

           
		
	 
	}else{
		echo "<br/> Something Wrong".mysqli_error($conn);
	}

	mysqli_close($conn);
}
else 
	 header("location:../view/userpersonalprofile.php");
		

?>