<?php
error_reporting(0);
session_start();

if(empty($_SESSION['lastName']) && $_SESSION['userType'] != "admin" )
{
	header("location:../view/login.html");

}
	
 
$filename=$_SESSION['lastName'];
$fileuploadpath="../noticepics/".$filename;
if(file_exists($fileuploadpath))
{
	unlink($fileuploadpath);
}
if(move_uploaded_file($_FILES['propic']['tmp_name'],$fileuploadpath))
{
	echo "notice picture added"; ?>
	<a href="../view/addnoticedescription.php">add description</a>
	<?php
}
else
	echo '<h1>Something went wrong , try again </h1>';
?>