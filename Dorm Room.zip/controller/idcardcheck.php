<?php
error_reporting(0);
session_start();
if(empty($_SESSION['lastName']))
{
	header("location:../view/login.html");

}
$filename=$_SESSION['userName'];
$fileuploadpath="../idpics/".$filename;
if(file_exists($fileuploadpath))
{
	unlink($fileuploadpath);
}
if(move_uploaded_file($_FILES['idcard']['tmp_name'],$fileuploadpath))
{
	echo 'id card uploaded
	<a href="../view/home.php">home</a>';
	
		
	
}
else
	echo "something went wrong . try again";
?>