<?php

$dbservername ="localhost";
$dbusername 	="root";
$dbpassword 	="";
$dbname 	="dormroom";

	
$conn = mysqli_connect($dbservername, $dbusername, $dbpassword, $dbname);
	
	if(!$conn){
		die("Connection Error!".mysqli_connect_error());
	}
	
	$sql = "select * from alluser where active='1'";
	if($result=mysqli_query($conn, $sql))
	{
		while($row=mysqli_fetch_assoc($result))
		{
			echo $row['userName'];
		}
	}


?>