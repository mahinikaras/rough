<?php
	session_start();
	error_reporting(0);
	if(empty($_SESSION['lastName']))
	{
		header("location:login.html");

	}
	$userName=$_GET['userName'];
	$dbservername ="localhost";
	$dbusername ="root";
	$dbpassword ="";
	$dbname ="dormroom";
	$conn = mysqli_connect($dbservername, $dbusername, $dbpassword, $dbname);
	if(!$conn){
			die("Connection Error!".mysqli_connect_error());
	}

	$sql="select * from alluser where userName='$userName'";
	//echo $sql;
	$result=mysqli_query($conn,$sql);
	$row = mysqli_fetch_assoc($result);
	if(mysqli_num_rows($result)==1){
		echo '<center><input type="button" name="userButton" onclick="chats()" id="userButton" value="'.$row[userName].'"></center>';
	}
	else
		echo "<center>Not Found</center>";
	
	
		

?>