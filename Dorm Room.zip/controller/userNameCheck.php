<?php
					
					$userName=$_GET['username'];
					
                     
                     $conn = mysqli_connect('localhost', 'root', '', 'dormroom');
                     $sql = "select * from alluser where userName='$userName'";
                     $result = mysqli_query($conn, $sql);

					if(mysqli_num_rows($result) == 1)
					{
						echo "in use";
					}
					else
						echo "&#10003";
					


?>