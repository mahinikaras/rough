<?php
session_start();

$dbservername ="localhost";
$dbusername 	="root";
$dbpassword 	="";
$dbname 	="dormroom";

	
$conn = mysqli_connect($dbservername, $dbusername, $dbpassword, $dbname);
	
	if(!$conn){
		die("Connection Error!".mysqli_connect_error());
	}
	
	$sql = "update alluser set active='0' where userName='".$_SESSION['userName']."'";
	mysqli_query($conn, $sql);


session_destroy();
header("location: ../view/login.html");

?>