<?php

	session_start();
	if(empty($_SESSION['lastName']) )
	{
		header("location:login.html");

	}

	$university = $_GET['university'];

	
	
	$conn = mysqli_connect('localhost', 'root', '', 'dormroom');

	if($_GET['university'] == "all"){
		$sql = "select * from alluser";
	}else{	
		$sql = "select * from alluser where university='".$university."'";
	}
	
	$result = mysqli_query($conn, $sql);

	while ($row = mysqli_fetch_assoc($result)) 
	{

		echo '<br/>';
		echo $row['id']." ~First Name : ".$row['firstName']." ~ Last Name : ".$row['lastName']." ~ User Name : ".$row['userName']." ~Email : ".$row['emailId']."~ DOB :".$row['dob']." ~Uni Id :".$row['universityId']."~ User Type : ".$row['userType']."<br/>";
	}

	
?>