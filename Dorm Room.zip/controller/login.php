<?php
    session_start();
	$dbservername ="localhost";
	$dbusername 	="root";
	$dbpassword 	="";
	$dbname 	="dormroom";
	$username = $_POST['name'];
	$password = $_POST['password'];
	
	$conn = mysqli_connect($dbservername, $dbusername, $dbpassword, $dbname);
	
	if(!$conn){
		die("Connection Error!".mysqli_connect_error());
	}
	
	$sql = "select * from alluser where password='$password' AND username='$username'";
	



	$result = mysqli_query($conn, $sql);
	
	if(mysqli_num_rows($result)== 1){
		
		 $row=mysqli_fetch_assoc($result);
		 
		 $_SESSION["id"]= $row['id'];
		 $_SESSION["firstName"]= $row['firstName'];
		 $_SESSION["lastName"]= $row['lastName'];
		 $_SESSION["userName"]= $row['userName'];
		 $_SESSION["emailId"]= $row['emailId'];
		 $_SESSION["password"]= $row['password'];
		 $_SESSION["dob"]= $row['dob'];
		 $_SESSION["university"]= $row['university'];
		 $_SESSION["universityId"]= $row['universityId'];
		 $_SESSION["department"]= $row['department'];
		 $_SESSION["gender"]=$row['gender'] ;
		 $_SESSION["userType"]=$row['userType'] ;

		 $sql2="update alluser set active='1' where userName='".$row['userName']."'";
			 if(mysqli_query($conn, $sql2))
			 {

			 }
			 else{
				echo "Result not found!";
			}
		 
		 if($_SESSION["userType"]=="CR" || $_SESSION["userType"]=="cr")
		 {
		 header("location:../view/home.php");
		 }
		 else if($_SESSION["userType"]=="admin")
			 header("location:../view/home.php");
		  else if($_SESSION["userType"]=="user")
			 header("location:../view/home.php");
		 
		//while($row=mysqli_fetch_assoc($result)){
			//echo "ID: ".$row['id']."<br/>NAME: ".$row['name']."<br/>PASSWORD: ".$row['password']."<br/><br/>";
			

		}



		
	else{
		echo "Result not found!";
	}

	mysqli_close($conn);
?>