<?php

	session_start();
	if(empty($_SESSION['lastName']) )
	{
		header("location:login.html");

	}

    $userName=$_SESSION['userName'];
	$firstName = $_POST['firstname'];
	$lastName=$_POST['lastname'];

	$emailId=$_POST['emailid'];

	$dob=$_POST['dob'];
	$university=$_POST['University'];

	$department=$_POST['department'];
	$gender=$_POST['gender'];






//db connection

	$dbservername ="localhost";
	$dbusername ="root";
	$dbpassword ="";
	$dbname ="dormroom";

	if(empty($firstName) ||empty($lastName)  ||empty($emailId) ||empty($dob) ||empty($university)
||empty($department)||empty($gender))
				{die("Please fill up all the fields\r\n");}
	$conn = mysqli_connect($dbservername, $dbusername, $dbpassword, $dbname);
	
	if(!$conn){
		die("Connection Error!".mysqli_connect_error());
	}
	
	$sql = "update alluser set firstName='$firstName',lastName='$lastName',emailId='$emailId',dob='$dob',university='$university',department='$department',gender='$gender' WHERE userName='$userName'";

	
	
	if(mysqli_query($conn, $sql)){

		$_SESSION['firstName']=$firstName;
		$_SESSION['lastName']=$lastName;
		$_SESSION['emailId']=$emailId;
		$_SESSION['dob']=$dob;
		$_SESSION['university']=$university;
		$_SESSION['gender']=$gender;
		$_SESSION['department']=$department;

		echo "<br/> Updated, User Information! <br/>	

		<a href=../view/home.php>Home</a>";
		
	}else{
		echo "<br/> Something Wrong".mysqli_error($conn);
	}

	mysqli_close($conn);

?>