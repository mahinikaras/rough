<?php
	session_start();
	if(empty($_SESSION['lastName']))
	{
		header("location:login.html");

	}
	
	$id=$_GET['id'];
	//echo $id;
	$dbservername ="localhost";
	$dbusername ="root";
	$dbpassword ="";
	$dbname ="dormroom";
	$conn = mysqli_connect($dbservername, $dbusername, $dbpassword, $dbname);
	if(!$conn){
			die("Connection Error!".mysqli_connect_error());
	}
	

						$sql = "select * from status where id='$id'" ;
						
								if($result=mysqli_query($conn, $sql)){
								while($row=mysqli_fetch_assoc($result))
								{
									echo $row['post'];
									

								}
							}
							else echo "problem";
									

?>
