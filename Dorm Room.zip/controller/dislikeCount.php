<?php
	session_start();
	if(empty($_SESSION['lastName']))
	{
		header("location:login.html");

	}
	
	$id=$_GET['id']+10000;
	$dbservername ="localhost";
	$dbusername ="root";
	$dbpassword ="";
	$dbname ="dormroom";
	$userName = $_SESSION['userName'];
	$conn = mysqli_connect($dbservername, $dbusername, $dbpassword, $dbname);
	if(!$conn){
			die("Connection Error!".mysqli_connect_error());
	}
	$sql2="select * from statusDislike where statusId='$id'";
	//echo $sql2;
	$result2=mysqli_query($conn,$sql2);
	while($row2=mysqli_fetch_assoc($result2))
	{
		if ($row2['userName']===$userName)
		{
			break;
		}
	}
	if($row2['userName']==$userName)
	{
		$sql="select * from status where id='$id'";
		$result=mysqli_query($conn,$sql);
		while($row=mysqli_fetch_assoc($result))
		{
			$dislike= $row['dislike'];
			echo $dislike;
		}
	}
	else

	{
		$sql3="insert into statusDislike values('','$id','$userName')";
		if(mysqli_query($conn,$sql3))
		{
			$sql="select * from status where id='$id'";
				$result=mysqli_query($conn,$sql);
				while($row=mysqli_fetch_assoc($result))
				{
					$dislike= $row['dislike'];
				}
			
				$dislike = $dislike+1;
			    
			    $sql = "update status set  dislike='$dislike' WHERE id='$id'";
			    if($result=mysqli_query($conn,$sql))
			    {
			    	echo $dislike;
			    }
			    else
			    {
			
			    }
			}
			else
			{

			}
	}
							

?>