<?php

	session_start();
	if(empty($_SESSION['lastName']) )
	{
		header("location:login.html");

	}

	$userName1=$_SESSION['userName'];
	$userName2=$_GET['userName2'];
	$msg=$_GET['message'];
	$message=$_SESSION['userName']." : ".$msg;
	
	
	$dbservername ="localhost";
	$dbusername ="root";
	$dbpassword ="";
	$dbname ="dormroom";
	$conn = mysqli_connect($dbservername, $dbusername, $dbpassword, $dbname);
	if(!$conn){
			die("Connection Error!".mysqli_connect_error());
	}
	$sql="select * from alluser where userName='$userName2'";
	$result=mysqli_query($conn,$sql);
	if(mysqli_num_rows($result)==1){
				$sql="insert into chat values('','$userName1','$userName2','$message')";
				mysqli_query($conn,$sql);
				$sql="select * from chat where (userName1='$userName1' or userName1='$userName2' ) and (userName2='$userName1' or userName2='$userName2' ) ";
				$result=mysqli_query($conn,$sql);
				while($row = mysqli_fetch_assoc($result))
				{
					echo $row['message']."<br/>";
				}
				
				}
	else
		echo "reciever doesn't exist";
	

?>