const request = require('request');

var geocodeAddress= (address,callback) => {
	console.log('\nFetching Weather Update.Please Wait.......');
	var encodedAddress = encodeURIComponent(address);
	request({
		url:`https://geocode.xyz/?locate=${encodedAddress}&json=1`,
		json:true
	},(error,response,body) =>{
		if(error){
			callback('unable to connect to geocode servers');
		}else if(body.longt == 0 && body.latt == 0){
			callback('unable to find the address');
		}else{
			var result = {
				Longitude:body.longt,
				Latitude:body.latt
			};
			callback(undefined,result);
		}
		
	})
};

module.exports = {
	geocodeAddress
};