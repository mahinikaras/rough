var getUser = (id,callback) => {
		var user = {
			id:id,
			name:'bro'
		};
		callback(user);
};

getUser(21,(user) =>{
	console.log(user);
});