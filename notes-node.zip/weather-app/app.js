const yargs = require('yargs');
const geocode = require('./geocode/geocode.js');
const weather = require('./weather/weather.js')
const argv = yargs
	.options({
		a:{
			describe:'Address to fetch weather for',
			demand:true,
			alias:'address',
			string:true
		}
	})
	.help()
	.argv;
	geocode.geocodeAddress(argv.address , (errorMessage,result) =>{
		if(errorMessage){
			console.log(errorMessage);
		}else{
			console.log(argv.address);
			console.log('--------');
			weather.fetchWeather(result.Latitude,result.Longitude,(errorMessage,result)=>{
		 		if(errorMessage){
		 			console.log(errorMessage)
		 		}else{
		 			console.log(`Summary : ${result.summary}\nTemperature : ${result.temperature}\nFeels Like: ${result.apparentTemperature}`);
		 		}
 			});
		}
	});
 


