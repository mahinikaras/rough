const request = require('request');

var fetchWeather =(latitude,longitude,callback) => {
	
	request({
				url:`https://api.darksky.net/forecast/2f55488392f26e242d620d31373cddc4/${latitude},${longitude}`,
				json:true	
			},(error,response,body) => {
				if(!error && response.statusCode == 200){
					var result = {
						summary : body.currently.summary,
						temperature : body.currently.temperature,
						apparentTemperature : body.currently.apparentTemperature
					};
					callback(undefined , result)
				}else{
					callback('unable to fetch weather');
				}
				
			});
};

module.exports = {
	fetchWeather
};