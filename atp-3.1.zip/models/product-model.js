var db=require('./db');
module.exports={
	insert:function(product,callback)
	{
		var sql="INSERT INTO produc VALUES(null,?,?,?)";	
		db.execute(sql,[product.name,product.quantity,product.price],function(result){
				if(result)
				{
					callback(true);
				}
				else
				{
					callback(false);
				}

		});
	},
	getAll:function(callback)
	{
		var sql="SELECT * from produc";	
		db.getResult(sql,[],function(result){
				callback(result);

		});
	},

	getById:function(id,callback)
	{
		var sql="SELECT * from produc WHERE id=?";	
		db.getResult(sql,[id],function(result){
				if(result.length>0)
				{
					callback(result[0]);
				}
				else
				{
					callback([]);
				}

		});
	},
	update:function(product,callback)
	{
		var sql="UPDATE produc SET name=?,quantity=?,price=? where id=?";	
		db.execute(sql,[product.name,product.quantity,product.price,product.id],function(result){
				if(result)
				{
					callback(true);
				}
				else
				{
					callback(false);
				}

		});
	},
	delete:function(id,callback)
	{
		var sql="DELETE from produc where id=?";	
		db.execute(sql,[id],function(result){
				if(result)
				{
					callback(true);
				}
				else
				{
					callback(false);
				}

		});
	},
}