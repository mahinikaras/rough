$(document).ready(function(){

	
	$("#submit").click(function(){
		if($("#name").val()==null  )
		{
			$("#message").html("All fields are required");
			console.log("all value must be required");
		}
	});



});

